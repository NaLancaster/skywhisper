#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "bkem.h"
#include "set_up.h"
#include "update_subscribers.h"










enum operation_modes{initialize=0, display_information=1, update_subscribers=2};
enum operation_modes current_mode;



int release;
int option;







void display_bkem_info(int number_of_users) {


	if(!release) printf("This is display_bkem_info().\n");
	
	char subscribers_file_name[100] = "/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/subscribers.txt";
	FILE *subscribers_file; 


	// open file for writing 
	subscribers_file = fopen (subscribers_file_name, "r"); 

	if(subscribers_file == NULL)
	{
		printf("subscribers list file: (%s) does not exist. \n", subscribers_file_name);
		return;
	}

	
	char list_content[number_of_users];

	int actual_length = fread(list_content,1,number_of_users,subscribers_file);
	fclose(subscribers_file);

	if(!release) printf("Subscriber's list actual_length: %d \n", actual_length);

	


	//check the sanity of this list (all indices should be between 0 and N-1 inclusive)
	for(int i=0; i<actual_length; i++)
	{
		if((list_content[i] < 0) || (list_content[i] > (number_of_users-1)))
		{
			printf("This list is corrupted, you need to reset the system.\n");
			return;
		}
	}

	printf("The total number of current subscribers: (%d)\n", actual_length);
	if(actual_length > 0)
	{
		printf("The indices of the current subscribers: { ");
		for(int i=0; i<actual_length; i++) printf("[%d] ", list_content[i]);
		printf("}\n");
	}

	return;
	
}



int main(int argc, const char *argv[]) 
{


	//check if enough number of argumets passed as input
	if(argc < 3)	
	{
		printf("BKEM Engine: NOT ENOUGH ARGUMENTS IN INPUT.\n");
		return 1;
	}


	option = atoi(argv[1]);
	release = atoi(argv[2]);

	if((release != 0) && (release != 1)) release = 0;

	if(!release) printf("BKEM Engine: option is: %d \n", option);


	if((option < initialize) || (option > update_subscribers))
	{
		printf("\nBKEM Engine: Invalid option.\n");
		return 1;
	}

	current_mode = option;


	if(current_mode == initialize)
	{
		if(argc < 4)
		{
			printf("BKEM Engine: initialize option - NOT ENOUGH ARGUMENTS IN INPUT.\n");
			return 1;
		}
		else
		{
			int number_of_users = atoi(argv[3]);
			bkem_initialization(number_of_users);
			return 0;
		}
	}
	else if(current_mode == display_information)
	{
		if(argc < 4)
		{
			printf("BKEM Engine: display_information option - NOT ENOUGH ARGUMENTS IN INPUT.\n");
			return 1;
		}
		else
		{
			int number_of_users = atoi(argv[3]);

			display_bkem_info(number_of_users);
			return 0;
		}
		
	}
	else if(current_mode == update_subscribers)
	{
		if(argc < 6)
		{
			printf("BKEM Engine: update_subscribers option - NOT ENOUGH ARGUMENTS IN INPUT.\n");
			return 1;
		}
		else
		{
			int number_of_users = atoi(argv[3]);
			int is_add = atoi(argv[4]);
			int user_index = atoi(argv[5]);

			return(update_bkem_subscribers(number_of_users, is_add, user_index, release));
		}
		
	}
	else
	{
		printf("BKEM Engine: INVALID OPTION.\n");
		return 1;
	}


	return 0;


}
