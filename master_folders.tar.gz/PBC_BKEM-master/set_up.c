#include "bkem.h"
//#include "bkem_engine.h"


#define check_if_ok 0
#define test_reconstruct 0
#define print_function 0


static bkem_global_params_t gps;	
//sys: a structure contains two elements: 1) a structure holding the public key PK. 2) an array of N private keys.
//PK is itself a structure as shown in bkem.h 
//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
static bkem_system_t sys; 


static char stego_key_file_name[12] = "keys/ZK.txt";
static char public_file_name[12] = "keys/PK.txt";
static char private_file_name[16] = "keys/di-";
static char subscribers_file_name[22] = "keys/subscribers.txt";



/*
*This function generates and stores a new 16-byte key that can be used as the secret stego key shared by
all nodes that are part of the stego network.
*/
void generate_new_stego_key()
{

	
	printf("This function should generate and store stego key in keys/ZK.txt\n");
	
	time_t t;
	FILE *zkFile; 
	const int stego_key_size = 16;
      
	// open file for writing 
	zkFile = fopen (stego_key_file_name, "w");


	unsigned char temp_buffer[stego_key_size];

	srand((unsigned) time(&t));

	for(int i=0; i<stego_key_size; i++) temp_buffer[i] = rand()%256;

	printf("The generated stego key is: ");
	for(int i=0; i<stego_key_size; i++) printf("%02x ", temp_buffer[i]);
	printf(" \n");


	int counter = fwrite(temp_buffer, 1, stego_key_size, zkFile);
	printf("Counter from writing temp_buffer to zkFile: %d \n", counter);


	fclose(zkFile);

	


}


static int in_set(int *Set, int length, int value)
{

	int found = 0;
	for(int i=0; i<length; i++)
	{
		if(Set[i] == value)
		{
			found = 1;
			break;
		}
	}
	return found;
}


static void print_elements()
{

	printf("PK: \n");
	element_printf("sys->PK->g = %B\n", sys->PK->g);
	for(int i=0; i<2*gps->B;i++)
	{
		printf("sys->PK->g_i[%d] = ", i);
		element_printf(" %B\n", sys->PK->g_i[i]);
	}

	unsigned char v_i_bytes[element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{

		len_v = element_to_bytes(v_i_bytes, sys->PK->v_i[i]);

		printf("sys->PK->v_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", v_i_bytes[j]);
		printf("\n");

		//element_printf(" %B\n", i, sys->PK->v_i[i]);
	}
	

	printf("----------------------------------------------------------------\n\n");

	unsigned char d_i_bytes[element_length_in_bytes(sys->d_i[0])];

	printf("Private keys: \n");
	
	int len_d = 0;
	for(int i=0; i<gps->N; i++)
	{	
		len_d = element_to_bytes(d_i_bytes, sys->d_i[i]);

		printf(" sys->d_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", d_i_bytes[j]);
		printf("\n");
		//element_printf("%B\n", i, sys->d_i[i]);
	} 
	printf("----------------------------------------------------------------\n\n");
		
	
}



void store_public_and_private()
{

	unsigned int c,k,j;
	
	printf("This function should store sys->PK and all sys->d_i to text files \n");
	

	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	printf("\n\n\nFirst, write all elements of sys->PK to (PK.txt).\n");

	
	//printf("Create and open a file \n");
	FILE *pkFile; 
      
	// open file for writing 
	pkFile = fopen (public_file_name, "w"); 

	//1- read sys->PK->g and write it to file
	unsigned char *g_bytes;
	int len_g = element_length_in_bytes(sys->PK->g); 
	//printf("Length of g from length function is: %d \n", len_g);
	g_bytes = (unsigned char *) malloc(len_g);
	int len_g1 = element_to_bytes(g_bytes, sys->PK->g);

	fwrite(g_bytes, len_g1, 1, pkFile);
	
	//2- read sys->PK->g_i and write to file
	unsigned char g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len = 0;
	for(int i=0; i<2*gps->B;i++)
	{
		//g_i_bytes[i] = (unsigned char *) malloc(element_length_in_bytes(sys->PK->g_i[i]));
		len = element_to_bytes(g_i_bytes[i], sys->PK->g_i[i]);

		/*printf("\nRead g_i_bytes[%d] in bytes = [ ",i);
		for (int t = 0; t < len; ++t) {
		    printf("%d ", g_i_bytes[i][t]);
		}
		printf("]\n\n");*/


		fwrite(g_i_bytes[i], len, 1, pkFile);
	}

	//3- read sys->PK->v_i and write to file
	unsigned char v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{
		len_v = element_to_bytes(v_i_bytes[i], sys->PK->v_i[i]);
		
		fwrite(v_i_bytes[i], len_v, 1, pkFile);
	}

	fclose(pkFile);


#if test_reconstruct
	printf("\n\n\nSecond, read (pk.txt) and re-construct public_key.\n");


	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	pubkey_t public_key;
	public_key = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	public_key->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	public_key->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	
	//set public_key->g using the bytes read in g_bytes
	/*Can you change this to pbc_malloc*/
	element_init_same_as(public_key->g,sys->PK->g);


	
	//open pkfile
	pkFile = fopen(public_file_name, "r");
	int res;

	//1- read and reconstruct public_key->g
	unsigned char new_g_bytes[128];
	
	res = fread(new_g_bytes,1,128,pkFile);
	//set public_key->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(public_key->g, new_g_bytes);

	//2- read and reconstruct public_key->g_i
	unsigned char new_g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//read from file
		res = fread(new_g_i_bytes[i],1,128,pkFile);

		//initialize public_key->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(public_key->g_i[i],sys->PK->g_i[i]);

		//set public_key->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(public_key->g_i[i], new_g_i_bytes[i]);
		//printf("For public_key->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	//3- read and reconstruct public_key->v_i
	unsigned char new_v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];
	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//read from file
		res = fread(new_v_i_bytes[i],1,128,pkFile);
		
		//initialize public_key->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(public_key->v_i[i],sys->PK->v_i[i]);

		//set public_key->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(public_key->v_i[i], new_v_i_bytes[i]);
		//printf("For public_key->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}


	//compare re-constructed public_key to original sys->PK
	int successful = 1;
	if(!element_cmp(public_key->g, sys->PK->g))
	{
		printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
	}
	else
	{
		successful = 0;
		printf("\n\n***** Failure: public_key->g != sys->PK->g *****\n");
	}


	
	for(int i=0; i<2*gps->B; i++)
	{
		if(!element_cmp(public_key->g_i[i],sys->PK->g_i[i]))
		{
			//printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: public_key->g_i[%d] != sys->PK->g_i[%d] *****\n",i,i);
		}
	}

	//if(successful) printf("\n\n***** Success: public_key->g_i[i] == sys->PK->g_i[i] for all 2*gps->B = %d *****\n", 2*gps->B);

	

	for(int i=0; i<gps->A; i++)
	{
		if(!element_cmp(public_key->v_i[i],sys->PK->v_i[i]))
		{
			//printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: public_key->v_i[%d] != sys->PK->v_i[%d] *****\n",i,i);
		}
	}

	//if(successful) printf("\n\n***** Success: public_key->v_i[i] == sys->PK->v_i[i] for all gps->A = %d *****\n", gps->A);
	if(successful) printf("\n\n***** Success: reconstructed public_key == sys->PK *****\n");


#endif

	
	




	
	printf("\n\nThird: take the private keys, convert it to bytes, and then write bytes to di-i.txt\n");

	FILE *privateFile;
	

	for(int i=0; i<gps->N; i++)
	{
		
		//convert corresponding private key to bytes
		unsigned char *private_bytes;
		int len_private = element_length_in_bytes(sys->d_i[i]); 
		private_bytes = (unsigned char *) malloc(len_private);
		int len01 = element_to_bytes(private_bytes,sys->d_i[i]);
		printf("Length of private key from conversion function is: %d \n", len01);
			
		
		//change file name 
		private_file_name[8] = '0' + (i/10);
		private_file_name[9] = '0' + (i%10);
		private_file_name[10] = '.';
		private_file_name[11] = 't';
		private_file_name[12] = 'x';
		private_file_name[13] = 't';
		privateFile = fopen (private_file_name, "w");
		fwrite(private_bytes, len01, 1, privateFile);
		fclose(privateFile);

	
		printf("Private key for user:(%d) has been written to file di-n.txt\n", i);
	} 


#if 0
	printf("\n\nFifth: read HDR from file and compare to original\n");
	 
      
	// open file for writing 
	hdrfile = fopen ("hdr.txt", "r");  


	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	

	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		res = fread(read_HDR_bytes[i],1,128,hdrfile);
		printf("For read_HDR_bytes[%d], the number of read bytes: %d \n", i, res);
	}

	fclose(hdrfile);


	//re-construct the HDR elements and compare with original HDR.
	//create new key pair: new_kp to store re-constructed HDR elements (and later to store retreived encryption key).
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));
	

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//printf("(A) step: %d \n", i);

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i], keypair->HDR[i]);

		//printf("(B) step: %d \n", i);

		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], read_HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}



	successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i], keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful)
	{
		printf("\n\n***** Success: Read HDR is same as original HDR *****\n");
	}
	else
	{
		printf("\n\n$$$$ Failure: Read HDR is NOT same as original HDR $$$$\n");
	}
#endif

#if test_reconstruct
	printf("\n\nFourth: read private keys from files and compare to original\n");

	unsigned char read_private[element_length_in_bytes(sys->d_i[0])];
	int len_set_bytes;

	successful = 1;

	for(int i=0; i<gps->N; i++)
	{
		
		//change file name 
		private_file_name[8] = '0' + (i/10);
		private_file_name[9] = '0' + (i%10);
		private_file_name[10] = '.';
		private_file_name[11] = 't';
		private_file_name[12] = 'x';
		private_file_name[13] = 't';
		// open file for rading 
		privateFile = fopen (private_file_name, "r");
		


		//read private key
		res = fread(read_private,1,128,privateFile);
		printf("\nFor read_private, the number of read bytes: %d \n", res);


		//create a new element_t to contain re-constructed private key
		element_t private_key;
		element_init_G1(private_key, gps->pairing);

		
		//set element (private key) from the given bytes
		len_set_bytes = element_from_bytes(private_key, read_private);
		printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

		//element_printf("The recreated private key for bytes: private_key = %B\n", private_key);

		//element_printf("The original private key for bytes: sys->d_i[i] = %B\n", sys->d_i[i]);

		if(!element_cmp(private_key/*new_struct->d_i[i]*/, sys->d_i[i]))
		{
			//printf("\n\n***** Success: read private key is same as original for i: (%d) *****\n",i);	
		}
		else
		{
			printf("\n\n$$$$$ Failure: read private key is NOT same as original for i: (%d) $$$$$\n",i);

			successful = 0;
		}

	
		
	} 


	if(successful)
	{
		printf("\n***** Success: All private keys match original  *****\n");
	}
	else
	{
		printf("\n\n$$$$$ Failure: read private key(s) is/are NOT same as original $$$$$\n");
	}
	

#endif

}



void reset_subscribers_list() {

	FILE *subscribers_file; 
      
	// open file for writing 
	subscribers_file = fopen (subscribers_file_name, "w"); 

	//int number_of_subscribers = 0;
	
	fwrite("", 1, 0, subscribers_file);

	fclose(subscribers_file);
}



void bkem_initialization(int number_of_users)
{

	FILE *param = fopen("a.param", "r");
	char buf[4096];
	fread(buf, 1, 4096, param);


	printf("\nSystem Keys Initialization\n\n");

	
	setup_global_system(&gps, (const char*) buf, number_of_users);

	printf("Global System parameters: N = %d, A = %d, B = %d\n\n", gps->N, gps->A, gps->B);


	generate_new_stego_key();


	
	setup(&sys, gps);
#if print_function
	print_elements();
#endif
	store_public_and_private();

	reset_subscribers_list();
}




