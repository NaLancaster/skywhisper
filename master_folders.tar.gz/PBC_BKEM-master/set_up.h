#include "bkem.h"


void bkem_initialization(int number_of_users);
