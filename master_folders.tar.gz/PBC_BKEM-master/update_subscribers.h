#include "bkem.h"


int update_bkem_subscribers(int number_of_users, int is_add, int user_index, int is_release);

