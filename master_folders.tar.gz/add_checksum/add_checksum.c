/*
This program reads the HDR file, hashes it, and add the LSB 16 bytes to the newely created
new file. If the he LSB 16 bytes of the hash value is ABCD, then the new file contains the 
following:
new file = ABCD || HDR
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "keccak.h"
#include "read_hex_file.h"


#define get_from_argv 1
#define get_from_terminal 0


char keyFile[16] = "keys/encK.txt";
char hdrFile[16] = "keys/HDR.txt";
char subscribers_file_name[100] = "/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/subscribers.txt";
char output_subscribers_list[18] = "subscribers.txt";
char output_authentication_msg[18] = "auth_msg.txt";
char h_hdrFile[18] = "keys/H_HDR.txt";
//----
char new_hdrFile[18] = "keys/n_HDR.txt";
char part_hash_file[16] = "keys/hash.txt";
//----
unsigned char hash[HASH_SIZE];
uint8_t buffer[2000];
union hash_state state;
//----
int release;


enum operation_modes{mode_generate=0, mode_partition=1, mode_check=2, mode_hash_key=3, mode_check_hash_key=4, mode_index_and_hash=5};
enum operation_modes current_mode;

//this function is copied from the Bytecoin project
void hash_process(union hash_state *state, const uint8_t *buf, size_t count) {
	keccak1600(buf, (int)count, (uint8_t*)state);
}

//hash private key, and write LSB two bytes into a file
int hash_private_key(char *private_file, char *hash_file)
{
	
	printf("\nThis is hash_private_key() and private_file: %s and hash_file: %s \n", private_file, hash_file);

	
	int counter = 0;

	

	FILE *fp = fopen(private_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", private_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# User fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(private_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", private_file);
		return 0;
	}
	
	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given private key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3- create new file (HHDR.txt)
	fp = fopen(hash_file, "w");

	//4- write LSB 2 byets of hash key_hash.txt.(bytes 0 and 1)
	counter = fwrite(hash, 1, 2, fp);
	printf("counter for  fwrite(hash, 1, 2, fp) = (%d) \n", counter);
	if(counter != 2)
	{
		printf("\nFAILURE: writing hash to (key_hash.txt).\n");
		fclose(fp);
		return 0;
	}

	fclose(fp);

	return 1;
}
		

/*This function does the following:
1- hashe the private key found in private_file
2- xor with random data R.
3- hash(R^hash(SK))
2- compare the LSB 2 bytes with the values in hash_file.
3- returns 1 if both are equal, and 0 otherwise.
*/
int check_hash_private_key(char *private_file, char *hash_file)
{
	
	if(!release) printf("\nThis is check_hash_private_key(), private_file: %s and hash_file: %s \n", private_file, hash_file);

	
	int counter = 0;

	
	//1- open and read the private key file
	FILE *fp = fopen(private_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", private_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# User fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	if(!release) printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(private_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", private_file);
		return 0;
	}
	
	//2- hash the read private key.	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given private key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}




	//3- read the given reference hash file
	fp = fopen(hash_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", hash_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# User fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int hash_file_size = ftell(fp);

	if(!release) printf("\n\nhash_file_size: (%d) \n", hash_file_size);

	if(hash_file_size != (2+HASH_SIZE))
	{
		printf("hash file should be of size (2 + HASH_SIZE)\n");
		fclose(fp);
		return 0;
	}

	fclose(fp);
	



	//open file for reading
	fp = fopen(hash_file, "r");

	


	/* Read and display reference hash */
	unsigned char reference_hash[2];
	counter = fread(reference_hash, 1, 2, fp);
	

	if(counter != 2)
	{
		printf("Failed to read reference hash from: \"%s\"\n", hash_file);
		return 0;
	}


	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("Reference hash: \n");
		for(int i=0; i<2; i++) printf("%02x ", reference_hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	unsigned char random_data[HASH_SIZE];

	/* Read and display received random data */
	counter = fread(random_data, 1, HASH_SIZE, fp);
	

	if(counter != HASH_SIZE)
	{
		printf("Failed to read received random numbers from: \"%s\"\n", hash_file);
		return 0;
	}


	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("Received random numbers: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", random_data[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	fclose(fp);


	//xor random data with hash of private key
	for(int i=0; i<HASH_SIZE; i++) buffer[i] = random_data[i]^hash[i];

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("random_data[i]^hash[i]: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//hash(random_data ^ hash(SK))
	hash_process(&state, buffer, HASH_SIZE);
	memcpy(hash, &state, HASH_SIZE);
	

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash(random_data^hash(SK)): \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//4- compare the LSB 2 bytes of hash[] with the read values from the reference hash file in buffer
	for(int i=0; i<2; i++)
	{
		if(hash[i] != reference_hash[i])
		{
			printf("Reference hash is NOT the same as the hash of the given key\n");
			return 0;
		}
	}

	

	return 1;
}


/*
This function returns the index of the subscriber if successful, and returns 99 otherwise
NOTE, THIS FUNCTION WONT WORK IF THE SYSTEM HAS 99 SUBCRIBERS OR MORE.
*/
int get_index_and_hash(char *request_file, char *hash_file)
{

	if(!release) printf("\nThis is get_index_and_hash(), request_file: %s and hash_file: %s \n", request_file, hash_file);

	
	int counter = 0;

	
	//1- open and read the request_file
	FILE *fp = fopen(request_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", request_file);
		return 99;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 99;
	}

	int file_size = ftell(fp);

	if(!release) printf("\n\nSubscription file size: (%d) \n", file_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(request_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, file_size, fp);
	
	
	fclose(fp);

	if(counter != file_size)
	{
		printf("Failed to read \"%s\"\n", request_file);
		return 0;
	}
	
	
	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("The given subscription file data: \n");
		for(int i=0; i<file_size; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3- read user index
	int user_index;
	user_index = (buffer[1] - 48) + (10 * (buffer[0] - 48));
	if(!release) printf("Subscriber user_index: %d\n", user_index);
	

	//4- open and write buffer[1..2] to hash_file
	//open file for writing
	fp = fopen(hash_file, "w");

	//write buffer[1][2] to hash_file
	counter = fwrite(&buffer[2], 1, file_size - 2, fp);
	if(!release) printf("counter for  fwrite(hash, 1, file_size - 2, fp) = (%d) \n", counter);
	if(counter != (file_size - 2))
	{
		printf("\nFAILURE: writing hash and random data to hash_file\n");
		fclose(fp);
		return 99;
	}

	fclose(fp);

	

	return user_index;
}



//This function reads the encryption key from encK.txt, and hashes it using hash_process()
int hash_key()
{
	
	
	int counter = 0;

	

	FILE *fp = fopen(keyFile, "r");
	if(fp == NULL)
	{
		printf("Failed to open: %s \n", keyFile);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("#  fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	if(!release) printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(keyFile, "r");
	if(fp == NULL)
	{
		printf("Failed to open: %s \n", keyFile);
		return 0;
	}

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", keyFile);
		return 0;
	}
	
	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release) printf("-------------------------------------------------------------------------\n");
	if(!release) printf("hash of the given key: \n");
	if(!release) for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
	if(!release) printf("\n");
	if(!release) printf("-------------------------------------------------------------------------\n");

	return 1;
}



/*
This function does the following
1) hash the key from encK.txt
2) read hdr from HDR.txt
3) create a third file H_HDR.txt that contains: (64 bytes || 8 bytes subscribers list || LSB 12 bytes of hash || HDR)
*/
int generate_hash()
{

	FILE *fp;
	int counter;

	const int number_of_users = 64;			 //number_of_users must be <= auth_msg_size (but never greater).
	const int auth_msg_size = 64;
	unsigned char authentication_msg[auth_msg_size]; //can not increase this more than 16, without changning HHDR format.
	


	FILE *subscribers_file; 

	//1- open and subscriber's list file
	subscribers_file = fopen (subscribers_file_name, "r"); 

	if(subscribers_file == NULL)
	{
		printf("subscribers list file: (%s) does not exist. \n", subscribers_file_name);
		return 0;
	}

	char list_content[number_of_users]; 

	int actual_length = fread(list_content,1,number_of_users,subscribers_file);
	if(!release) printf("\n actual_length of subscribers file = %d \n", actual_length);
	fclose(subscribers_file);


	//2- hash encryption key file
	if(!hash_key()) return 0;

	//3- read HDR to new file
	fp = fopen(hdrFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END)) 
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}


	int hdr_size = ftell(fp);

	if(!release) printf("\n\nHDR file size: (%d) \n", hdr_size);

	fclose(fp);

	//open file for reading
	fp = fopen(hdrFile, "r");
	// Read HDR into buffer
	counter = fread(buffer, 1, hdr_size, fp);

	fclose(fp);

	if(counter != hdr_size)
	{
		printf("Failed to read \"%s\"\n", hdrFile);
		return 0;
	}


	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hdr: \n");
		for(int j=0; j<hdr_size; j++) printf("%02x ", buffer[j]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}
	
	//4- create new file (HHDR.txt)
	fp = fopen(h_hdrFile, "w");



	//5- write 64 bytes authentication msg at the start of HHDR
	char private_key_file[16] = "keys/di-00.txt";
	unsigned char hdr_and_key[hdr_size + 128];
	unsigned char temp[HASH_SIZE];

	memcpy(hdr_and_key, buffer, hdr_size);
	
	for(int i=0; i<auth_msg_size; i++)
	{
		if(i<number_of_users)
		{
			private_key_file[8] = '0' + (i/10);
			private_key_file[9] = '0' + (i%10);
			if(!release) printf("should hash key file: %s \n", private_key_file);


			//open private key file for reading
			FILE *fpk = fopen(private_key_file, "r");
			// Read key into hdr_and_key
			counter = fread(&hdr_and_key[hdr_size], 1, 128, fpk);

			fclose(fpk);

			if(counter != 128)
			{
				printf("Failed to read \"%s\"\n", private_key_file);
				return 0;
			}


			if(!release)
			{
			/*	
				printf("-------------------------------------------------------------------------\n");
				printf("hdr_and_key: \n");
				for(int j=0; j<hdr_size + 128; j++) printf("%02x ", hdr_and_key[j]);
				printf("\n");
				printf("-------------------------------------------------------------------------\n");
			*/
			}

			union hash_state sub_state;
			hash_process(&sub_state, hdr_and_key, hdr_size+128);
			memcpy(temp, &sub_state, HASH_SIZE);

			if(!release)
			{
				printf("-------------------------------------------------------------------------\n");
				printf("hash of the given private key: \n");
				for(int j=0; j<HASH_SIZE; j++) printf("%02x ", temp[j]);
				printf("\n");
				printf("-------------------------------------------------------------------------\n");
			}

			authentication_msg[i] = temp[0];
		}
		else
		{
			authentication_msg[i] = 'a'+i;
		}
		if(!release) printf(".\n");
	}

	counter = fwrite(authentication_msg, 1, auth_msg_size, fp);
	if(!release) printf("counter for fwrite(authentication_msg, 1, auth_msg_size, fp); = (%d) \n", counter);
	if(counter != auth_msg_size)
	{
		printf("\nFAILURE: writing authentication_msg to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}
	
	//6- write 4 bytes subscribers list to new file
	//first, fill remaining bytes with values of 99
	for(int i=actual_length; i<number_of_users; i++)list_content[i]=99;

	unsigned char binary_encoded_list[8];
	int binary_value_one = 0;
	int binary_value_two = 0;
	int index_exists = 0;
	for(int i=0; i<number_of_users; i++)
	{
		index_exists = 0;
		for(int j=0; j<number_of_users; j++)
		{
			if(list_content[j] == i) //this index exists in the subscribers list
			{
				index_exists = 1;
				break;
			}
		}
		if(index_exists)
		{
			if(i < 32) binary_value_one = binary_value_one | (1 << i);
			if(i >=32) binary_value_two = binary_value_two | (1 << (i-32));	
		}
		
	}
	if(!release) printf("\n\nbinary_value_one: %d \n", binary_value_one);
	if(!release) printf("\n\nbinary_value_two: %d \n", binary_value_two);
	for(int i=0; i<8; i++)
	{
		if(i<4) binary_encoded_list[i] = (binary_value_one >> (i*8)) & 0xff;
		if(i>=4) binary_encoded_list[i] = (binary_value_two >> ((i-4)*8)) & 0xff;
	}
	if(!release)
	{
		for(int i=0; i<8; i++) printf("binary_encoded_list[%d]: %02x \n",i,binary_encoded_list[i]);
	}

	counter = fwrite(binary_encoded_list, 1, 8, fp);
	if(!release) printf("counter for fwrite(binary_encoded_list, 1, 8, fp) = (%d) \n", counter);
	if(counter != 8)
	{
		printf("\nFAILURE: writing subscribers list to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}

	//7- write LSB 12 byets of hash to new file.(bytes 0...11)
	counter = fwrite(hash, 1, 12, fp);
	if(!release) printf("counter for  fwrite(hash, 1, 12, fp) = (%d) \n", counter);
	if(counter != 12)
	{
		printf("\nFAILURE: writing hash to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}

	

	//8- write HDR to new file
	counter = fwrite(buffer, 1 , hdr_size, fp);
	if(!release) printf("counter for fwrite(buffer, 1 , hdr_size, fp) = (%d) \n", counter);
	if(counter != hdr_size)
	{
		printf("\nFAILURE: writing HDR to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}
	

	fclose(fp);

	return 1;
}



/*
This function reads h_hdrfile and produces four files auth_msg.txt, subscriber.txt, hdr.txt and hash_part.txt*/
int partition_file()
{
	FILE *fp;
	int counter;


	//1- read H_HDR to new file
	fp = fopen(h_hdrFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END)) 
	{
		printf("#  fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int h_hdr_size = ftell(fp);
	if(!release) printf("\n\nH_HDR file size: (%d) \n", h_hdr_size);
	fclose(fp);

	//open file for reading
	fp = fopen(h_hdrFile, "r");
	// Read HDR into buffer
	counter = fread(buffer, 1, h_hdr_size, fp);
	fclose(fp);
	if(counter != h_hdr_size)
	{
		printf("Failed to read \"%s\"\n", h_hdrFile);
		return 0;
	}

	//char new_hdrFile[11] = "n_HDR.txt";
	//char part_hash_file[10] = "hash.txt";

	//3- create a new file and write the first 16 bytyes to it
	fp = fopen(output_authentication_msg, "w");
	counter = fwrite(buffer, 1 , 16, fp);
	if(!release) printf("counter for fwrite(buffer, 1 , 16, fp) = (%d) \n", counter);
	if(counter != 16)
	{
		printf("\nFAILURE: writing 1st 16 bytes to auth_msg file: %s.\n", output_authentication_msg);
		fclose(fp);
		return 0;
	}
	fclose(fp);

	//4- create a new file and write 4 bytes to it
	fp = fopen(output_subscribers_list, "w");
	counter = fwrite(&buffer[16], 1 , 4, fp);
	if(!release) printf("counter for fwrite(&buffer[16], 1 , 4, fp) = (%d) \n", counter);
	if(counter != 4)
	{
		printf("\nFAILURE: writing 4 bytes to subscribers file: %s.\n", output_subscribers_list);
		fclose(fp);
		return 0;
	}
	fclose(fp);
	
	//4- create a new file and write 12 bytes to it.
	fp = fopen(part_hash_file, "w");
	

	//write 1st 12 bytes from buffer to new file
	counter = fwrite(&buffer[20], 1 , 12, fp);
	if(!release) printf("counter for fwrite(&buffer[20], 1 , 12, fp) = (%d) \n", counter);
	if(counter != 12)
	{
		printf("\nFAILURE: writing 12 bytes to Hash file: %s.\n", part_hash_file);
		fclose(fp);
		return 0;
	}
	fclose(fp);

	//5- create a new file and write remaining bytes to it (write HDR to new file).
	fp = fopen(new_hdrFile, "w");

	//write 1st 16 bytes from buffer to new file
	counter = fwrite(&buffer[32], 1 , (h_hdr_size-32), fp);
	if(!release) printf("counter for fwrite(&buffer[32], 1 , (h_hdr_size-32), fp) = (%d) \n", counter);
	if(counter != (h_hdr_size-32))
	{
		printf("\nFAILURE: writing HDR to new file: %s.\n", new_hdrFile);
		fclose(fp);
		return 0;
	}
	fclose(fp);


	return 1;

	
}

/*
This function reads and hashes encK.txt
and compare the 1st 12 bytes of the hash value with the bytes in hash.txt
return 1 --> successful (same values)
return 0 --> not the same.
*/
int check()
{

	//1- hash key in encK.txt
	if(!hash_key())
	{
		printf("\nFAILURE: problem in hash_key().\n");
		return 0;
	}

	//2- read part_hash_file
	FILE *fp = fopen(part_hash_file, "r");
	int counter = fread(buffer, 1, 12, fp);
	fclose(fp);
	if(counter != 12)
	{
		printf("Failed to read \"%s\"\n", part_hash_file);
		return 0;
	}

	printf("-------------------------------------------------------------------------\n");
	printf("Read hash value: \n");
	for(int i=0; i<12; i++) printf("%02x ", buffer[i]);
	printf("\n");
	printf("-------------------------------------------------------------------------\n");


	//3 - compare hash read from file and computed hash value 
	int not_the_same = 0;
	for(int i=0; i<12; i++)
	{
		if(buffer[i] != hash[i]) not_the_same = 1;
	}

	if(not_the_same)
	{
		printf("\nFAILURE: the read value from file does not match computed hash value.\n");
		return 0;
	}

	return 1;
}

// main
int main(int argc, char **argv)
{
	
	//printf("\n\n************************************************************************ \n"); 
	//printf("This program is hashing HDR, make sure  %s file exists.\n", hdrFile);
	//printf("************************************************************************ \n");

#if get_from_argv
	int option = (argc > 1) ? atoi(argv[1]) : 0;
	release = (argc > 2) ? atoi(argv[2]) : 0;


	if(!release) printf("argv[1]: %s \n", argv[1]);
	if(!release) printf("argv[2]: %s \n", argv[2]);

	
#endif	

#if get_from_terminal
	int option;
	release = 0;
	do
	{
	
		printf("\n\n************************************************************************ \n"); 
		printf("Enter (0) to generate hash for a given encK.txt and add it with HDR.txt to a new file H_HDR.txt.\n");
		printf("Enter (1) to partition H_HDR.txt into hash.txt, subscribers list, and n_HDR.txt.\n");
		printf("Enter (2) to hash encK.txt and compare the 1st 12 bytes with the values in hash.txt.\n");
		printf("************************************************************************ \n");
		
		option = getchar() - 48;
		printf("option: %d \n", option);

		if((option < 0)||(option > 2))
		{
			printf("Invalid input \n");
		}
	}while((option < 0)||(option > 2));
#endif	
		 
	


	if(!release) printf("option: %d \n", option);
	if(!release) printf("release: %d \n", release);

	if((option < mode_generate) || (option > mode_index_and_hash))
	{
		printf("\nInvalid option - choose either mode_generate or mode_check.\n");
		return 0;
	}

	current_mode = option;

	if(current_mode == mode_generate)
	{
		if(!release) printf("\nCurrent mode: mode_generate.\n");

		if(!release) printf("argc: %d \n", argc);
		if(!release) printf("argv[3]: %s \n", argv[3]);

		if(generate_hash())
		{
			if(!release) printf("\nSUCCESS: generate_hash() is successful.\n");
			return 0;
		}
		else
		{
			printf("\nFAILURE: problem in generate_hash().\n");
			return 1;
		}
	}
	else if(current_mode == mode_partition)
	{
		if(!release) printf("\nCurrent mode: mode_partition.\n");
		if(partition_file())
		{
			if(!release) printf("\nSUCCESS: partition_file() is successful.\n");
			return 0;
		}
		else
		{
			printf("\nFAILURE: problem in partition_file().\n");
			return 1;
		}
	}
	else if(current_mode == mode_check)
	{
		if(!release) printf("\nCurrent mode: mode_check.\n");
		if(check())
		{
			if(!release) printf("\nSUCCESS: check() is successful.\n");
			return 0;
		}
		else
		{
			printf("\nFAILURE: problem in check().\n");
			return 1;
		}
	}
	else if(current_mode == mode_hash_key)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_hash_key, argv[3]:%s and and argv[4]: %s.\n", argv[3], argv[4]); 

			if(hash_private_key(argv[3],argv[4]))
			{
				if(!release) printf("\nSUCCESS: hash_private_key() is successful.\n");
				return 0;
			}
			else
			{
				printf("\nFAILURE: problem in hash_private_key().\n");
				return 1;	
			}
		}
		else
		{
			printf("\nFAILURE: provide name of private key file and hash file.\n");
			return 1;
		}
	}
	else if(current_mode == mode_check_hash_key)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_check_hash_key, argv[3]:%s and and argv[4]: %s.\n", argv[3], argv[4]); 

			if(check_hash_private_key(argv[3],argv[4]))
			{
				if(!release) printf("\nSUCCESS: check_hash_private_key() is successful.\n");
				return 0;
			}
			else
			{
				printf("\nFAILURE: problem in check_hash_private_key().\n");
				return 1;	
			}
		}
		else
		{
			printf("\nFAILURE: provide name of private key file and hash file.\n");
			return 1;
		}
	}
	else if(current_mode == mode_index_and_hash)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_index_and_hash, argv[3]:%s and and argv[4]: %s.\n", argv[3], argv[4]); 

			return (get_index_and_hash(argv[3],argv[4]));

		}
		else
		{
			printf("\nFAILURE: provide subscription request and hash file name.\n");
			return 99; //failure
		}

	}

	
	printf("\n");
	printf("\n");
	
	
	
    

    	return 0;
}
