#!/bin/bash


subscribers_list="/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/subscribers.txt"
remote_subscription_request_file="/home/user/Desktop/broadcast_bytecoin/bcndev/sub_request.txt"
remote_revocation_request_file="/home/user/Desktop/broadcast_bytecoin/bcndev/rev_request.txt"
remote_hdr_file="/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/HDR.txt"
remote_encK_file="/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/encK.txt"
broadcast_msg_file="/home/user/Desktop/broadcast_bytecoin/bcndev/received_msg.txt"
encK_file="./keys/encK.txt"
hdr_file="./keys/HDR.txt"
hhdr_file="./keys/H_HDR.txt"
subscription_request_file="sub_request.txt"
revocation_request_file="rev_request.txt"
hash_file="./keys/hash_private.txt"




cmd=0
add_remove=0

release=1
debug=0


initialize_keys=1
remove_user=2
send_msg=3
display=4
disp=9


#commands/options for BKEM engine, either initialize, or display information, or update subscribers (and generate new HDR).
bkem_engine_initialize=0
bkem_engine_display_info=1
bkem_engine_update_subscribers=2

num_of_users=64


RED='\033[0;31m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color







check_new_broadcast_msg () {

	#printf "check_new_broadcast_msg() is started.\n"


	#check if broadcast msg exists in bcndev directory
	if [ -f "$broadcast_msg_file" ]
	then
		#echo "$broadcast_msg_file is found"
		echo -e "${RED}INFO:${NC} a new broadcast message is received."

		#move this file to current directory
		mv $broadcast_msg_file .
		
		#decrypt and extract message.
		/home/user/Desktop/broadcast_bytecoin/encrypt_decrypt/./enc_engine 1 $release

		if [ "$?" == "0" ]
		then
			echo -e "${RED}INFO:${NC} message is successfully extracted and decrypted."
			message=$(cat dmsg.txt)
			printf "\n**************************************************************************\n"
			echo -e "${RED}INFO:${NC} received message is: {${PURPLE}$message${NC}}"
			printf "****************************************************************************\n"

			rm dmsg.txt
		else
			echo FAILURE IN DECRYPTING MESSAGE 
		fi

		#in both cases, remove broadcast_msg_file from current directory.
		rm received_msg.txt


		#display menu
		display_list

	fi

	#printf "check_new_broadcast_msg() is finished.\n"
}


add_remove_user_and_set_new_hdr () {

	#printf "add_remove_user_and_set_new_hdr() started.\n"

	#printf "user index: $user_index \n"


	cd ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/

	#execute bkem_engine (64=n(users), 1= add/0=remove, 0=release, and $user_index)
	./bkem_engine $bkem_engine_update_subscribers $release $num_of_users $add_remove $user_index


	if [ "$?" == "0" ]
	then
		echo -e "${RED}INFO:${NC} update_subscribers is successful."

		cd ~/Desktop/broadcast_bytecoin/broadcast_bash/
		
		#copy new HDR file and encK.txt from remote directory to current directory's /keys folder
		cp $remote_hdr_file $hdr_file
		cp $remote_encK_file $encK_file


		#call generate_HHDR function
		generate_HHDR
		

		#create packet.txt = CMD || H_HDR
		cmd=1
		create_packet
		#5) invoke invoke: /home/user/Desktop/wallet_bash/create_and_send.sh \n"
		send_big_transaction

		echo -e "${RED}INFO:${NC} Updated HDR has been broadcast successfully.\n"

		
		
	else
		echo -e "${RED}INFO:${NC} FAILURE in update_subscribers (may be this is due to an empty list)"
	fi
}




check_subscription_requests () {

	#printf "check_subscription_requests() started.\n"
	#check if a subscription request exists.
	if [ -f "$remote_subscription_request_file" ]
	then
		#echo $remote_subscription_request_file is found.
		
		#move file to current directory
		mv $remote_subscription_request_file .

		#find out the user index and create hash_private.txt
		/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 5 $release $subscription_request_file $hash_file

		#get user_index from return value
		user_index=$?


		#echo user index $user_index
		
		#if user_index < 10, then add '0' as a prefix - otherwise, file wont be found.
		if [ "$user_index" -lt "10" ]
		then
			user_index=0$user_index
			#echo Modified user index $user_index
		fi

		echo -e "${RED}INFO:${NC} Subscription request from user with index: $user_index\n"

		private_key_file="keys/di-$user_index.txt"

		#echo private key \file\: $private_key_file

		if [ -f "$private_key_file" ]
		then
			#hash the private key of this subscriber and compare 2 LSB of the hash with the reference hash in hash_file
			/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 4 $release $private_key_file $hash_file


			if [ "$?" == "0" ]
			then
				echo -e "${RED}INFO:${NC} Valid subscription request from user with index: $user_index\n"
				
				add_remove=1 #add
				add_remove_user_and_set_new_hdr
			else
				echo -e "${RED}INFO:${NC} INVALID subscription request from user with index: $user_index \n"
			fi
		else
			printf "Private key file does not exist. \n"
			printf "RESOLVE THIS ISSUE. \n"
		fi

		#in all cases, remove subscription file from current directory
		rm $subscription_request_file


		#display menu
		display_list

		


	fi
	#printf "check_subscription_requests() finished.\n"
}




#This function has been commented out, as subscribers are unlikely to request revocation.
#Users can still be revoked by the master node as done in revoke_user
check_revocation_requests () {

	printf "check_revocation_requests() started.\n"
	
	#check if a revocation request exists.
	if [ -f "$remote_revocation_request_file" ]
	then
		echo $remote_revocation_request_file is found.
		
		#move file to current directory
		mv $remote_revocation_request_file .

		#find out the user index and create hash_private.txt
		/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 5 $release $revocation_request_file $hash_file

		#get user_index from return value
		user_index=$?

		echo user index $user_index
		
		if [ "$user_index" -lt "10" ]
		then
			user_index=0$user_index
			echo Modified user index $user_index
		fi
		private_key_file="keys/di-$user_index.txt"

		echo private key \file\: $private_key_file

		if [ -f "$private_key_file" ]
		then
			#hash the private key of this user and compare 2 LSB of the hash with the reference hash in hash_file
			/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 4 $release $private_key_file $hash_file


			if [ "$?" == "0" ]
			then
				printf "Valid revocation request from user with index: $user_index \n"
				
				#add_remove=0 #remove
				#add_remove_user_and_set_new_hdr
			else
				printf "INVALID revocation request from user with index: $user_index \n"
			fi
		else
			printf "Private key file does not exist. \n"
			printf "RESOLVE THIS ISSUE. \n"
		fi

		


	fi
	
	printf "check_revocation_requests() finished.\n"


}


initialize_pbc_bkem () {

	printf "This is initialize_pbc_bkem function \n"

	cd ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/

	#initialize keys for N=16 users
	./bkem_engine $bkem_engine_initialize $release $num_of_users

	cd ~/Desktop/broadcast_bytecoin/broadcast_bash/

	#remove older directory with all of its content	
	rm -r keys

	#create new directory
	mkdir keys


	#copy new steo key to keys directory
	cp ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/ZK.txt ./keys


	#move PK.txt and all private key files to keys folder within current directory.
	cp ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/PK.txt ./keys


	cp ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/di-* ./keys

	echo -e "${RED}INFO:${NC} New keys are found in ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/\n"
}


#This function removes the subscription of the user whose index is specified.
revoke_user () {
	printf "Enter user's index to be revoked (0-63): "
	read user_index

	echo -e "${RED}INFO:${NC} chosen user index: $user_index"
		
	#if user_index < 10, then add '0' as a prefix - otherwise, file wont be found.
	if [ "$user_index" -lt "10" ]
	then
		user_index=0$user_index
		#echo Modified user index $user_index
	fi


	private_key_file="keys/di-$user_index.txt"

	#echo private key \file\: $private_key_file

	if [ -f "$private_key_file" ]
	then
		add_remove=0 #remove
		add_remove_user_and_set_new_hdr
	else
		printf "Private key file does not exist - check user index is valid! \n"
		printf "RESOLVE THIS ISSUE. \n"
	fi

}


#This function should update the list of subscribers 
#(may be the list is in a text file which is after that read by PBC_BKEM..) 
#before generating new HDR.
update_subscribers_list () {
	printf "This is update_subscribers_list function\n"
	printf "DO THIS AFTER IMPLEMENTING MECHANISMS FOR RECEIVING SUBSCRIBTION REQUESTS\n"
	printf "THIS CAN BE EXECUTED AUTOMATICALLY AFTER NEW SUBSCRIBTIONS/REVOCATIONS.\n"
}

generate_HDR () {
	printf "This is generate_HDR function\n"
	printf "DO THIS LATER - FOR NOW JUST COPY THESE FILE: (HDR.txt and encK.txt) IN CURRENT DIRECTORY.\n"
	
	cp ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/hdr.txt HDR.txt
	cp ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/encK.txt .
}

#This function executes ~/Desktop/broadcast_bytecoin/add_checksum/./ha to generate H_HDR
generate_HHDR () {
	#printf "This is generate_HHDR function\n"
	# pass the value 0 to this executable to execute the 'generate' mode
	# and pass 1 to stop debug messages.
	# pass number of users
	~/Desktop/broadcast_bytecoin/add_checksum/./ha 0 $release $num_of_users
}



#This function creates a new file called packet.txt = CMD || H_HDR
create_packet () {
	#printf "This is create_packet function\n"
	#echo cmd\: $cmd
	if [ $cmd -eq 1 ]
	then
		touch packet.txt
		echo -n -e $cmd > packet.txt && cat $hhdr_file >> packet.txt
	fi
}

#This function invokes /home/user/Desktop/wallet_bash/create_and_send.sh
# and this function is called when sending a new HDR command
# (when a user is added/removed from list).
send_big_transaction () {
	#printf "This is send_big_transaction function\n"

	#before invoking create+send transaction, copy packet.txt to same directory as wallet
	cp packet.txt ~/Desktop/broadcast_bytecoin/bcndev/ 

	#invoke /home/user/Desktop/wallet_bash/create_and_send.sh
	/home/user/Desktop/wallet_bash/create_and_send.sh



	#remove packet.txt from current directory
	rm packet.txt
}


#This function invokes /home/user/Desktop/wallet_bash/create_and_send2.sh
send_transaction () {
	#printf "This is send_transaction function\n"

	#before invoking create+send transaction, copy packet.txt to same directory as wallet
	cp packet.txt ~/Desktop/broadcast_bytecoin/bcndev/ 

	#invoke /home/user/Desktop/wallet_bash/create_and_send.sh
	/home/user/Desktop/wallet_bash/create_and_send2.sh

	#remove packet.txt from current directory
	rm packet.txt
}


#This function displays system-wide information:
#1- System parameters (number of maximum users).
#2- The number of current subscribers, and their indices.
display_information () {

	echo This is display_information \(\).

	echo -e "${BLUE}"
	echo '***********************************************************************'
	echo System information\:
	echo The total number of users \(potentional subscribers\): $num_of_users

	#cd ~/Desktop/broadcast_bytecoin/PBC_BKEM-master/
	~/Desktop/broadcast_bytecoin/PBC_BKEM-master/bkem_engine $bkem_engine_display_info $release $num_of_users

	echo '***********************************************************************'
	echo -e "${NC}"
}




broadcast_msg () {
	#printf "This is broadcast_msg () function \n"

	#check if encK.txt file exists (i.e. this user is a subscriber)
	if [ -f $encK_file ]
	then
		printf "Enter your broadcast message here (Less than 200 bytes): "
		read message

		msg_length=$(echo $message | awk '{print length}')

		echo -e "\n${RED}INFO:${NC} message length: $msg_length Bytes."

		if [ $msg_length -le 200 ]
		then
			echo -e "${RED}INFO:${NC} entered message: {$message}"

			#remove msg.txt if it already exists
			if [ -f msg.txt ]
			then
				rm msg.txt
			fi

			#create msg.txt
			touch msg.txt

			echo -n -e $message > msg.txt

			#execute enc_engine and pass 0 0 (encryption + release)
			/home/user/Desktop/broadcast_bytecoin/encrypt_decrypt/./enc_engine 0 $release


			#remove packet.txt if it exists
			if [ -f packet.txt ]
			then
				echo packet.txt exists - remove it

				rm packet.txt
			fi
			
			#create new packet.txt file
			touch packet.txt

			
			cmd=4
			echo -n -e $cmd > packet.txt && cat emsg.txt >> packet.txt


			#3- send the created command packet
			send_transaction

			echo -e "${RED}INFO:${NC} Broadcast message is successfully sent.\n"


			#rm packet.txt
			rm msg.txt && rm emsg.txt
		else

			echo -e "${RED}INFO: Although it is possible to broadcast longer messages, "
			echo -e "     we limit the length of messages in this proof-of-concept to 200 Bytes. ${NC}"
		fi

		

	else

		echo -e "${RED}INFO:${NC} encK.txt does not exist."
	fi
}



display_list () {

	echo ' '
	printf "************************************************************************************\n"
	printf "Enter one of the following options:\n"
	printf "1: to set up new public and private keys.\n"
	printf "2: to remove a subscriber. \n"
	printf "3: to send a broadcast message. \n"
	printf "4: to display system-wide information. \n"
	printf "9: to display this list. \n"
	printf "************************************************************************************\n"
	echo ' '

}







printf "********************************\n"
printf "\nThis is Master Broadcast Node.\n\n"
printf "********************************\n\n"


display_list


while true
do
	

	#read option
	read -t 1 option

	
	if [ -z "$option" ]
	then
		#echo NO input is entered.
		input_entered=0
	else
		input_entered=1
	fi

	if [ $input_entered -eq 1 ]
	then

		#echo The selected option is\: $option

		if [ "$option" -lt "$initialize_keys" ] || [ "$option" -gt "$disp" ]
		then
			echo Invalid input
		fi


		if [ "$option" -eq "$initialize_keys" ]
		then
			#initialize_pbc_bkem
			echo This \command is commented out \while demonstration, and should be uncommented \if keys are to be regenerated.
		fi

		if [ "$option" -eq "$remove_user" ]
		then
			revoke_user

		fi



		if [ "$option" -eq "$send_msg" ]
		then
			broadcast_msg
		fi

		if [ "$option" -eq "$display" ]
		then
			display_information
		fi

		#if [ "$option" -eq "$disp" ]
		#then
			display_list
		#fi


	fi

	#if [ "$option" -eq "$empty_subscribers" ]
	#then
		#empty subscribers list
	#	rm $subscribers_list
	#	touch $subscribers_list

	#	printf "\nSubscribers list: $subscribers_list has been emptied.\n"
	#fi



	check_subscription_requests
	#check_revocation_requests
	check_new_broadcast_msg
	










	



	
done




