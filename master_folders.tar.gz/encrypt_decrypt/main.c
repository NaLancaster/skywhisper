#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "keccak.h"
#include "oaes_lib.h"
#include "read_hex_file.h"



char msgFile[10] = "msg.txt";
char e_msgFile[10] = "emsg.txt";
char r_msgFile[18] = "received_msg.txt";
char d_msgFile[10] = "dmsg.txt";
char encKFile[16] = "keys/encK.txt";

#define MAX_SIZE  4000
#define BROADCAST_KEY_SIZE 128
#define block_len 16

unsigned char data[MAX_SIZE];
unsigned char broadcast_key[BROADCAST_KEY_SIZE];
unsigned char actual_key[block_len];
unsigned char first_IV[block_len];

enum operation_modes{mode_enc=0, mode_dec=1};
enum operation_modes current_mode;

int option;
int release;

unsigned char hash[HASH_SIZE];
union hash_state state;

//this function is copied from the Bytecoin project
void hash_process(union hash_state *state, const uint8_t *buf, size_t count) {
	keccak1600(buf, (int)count, (uint8_t*)state);
}

void initialize_rand() 
{
	time_t t;
	/* Intializes random number generator */
	srand((unsigned) time(&t));
}

unsigned char get_rand()
{
	return (unsigned char) (rand() % 256);
}


//This function reads the encryption key from encK.txt, and hashes it using hash_process()
int extract_key()
{
	if(!release) printf("This is extract_key() function \n");
	
	int counter = 0;

	FILE *keyF = fopen(encKFile, "r");

	// find the size of the file
	if(fseek(keyF, 0, SEEK_END))
	{
		printf("\n\n^^**^^ FAILURE: fseek(keyF, 0, SEEK_END) returned false. ^^**^^\n\n");
		fclose(keyF);
		return 1;
	}

	int key_size = ftell(keyF);

	if(!release) printf("\n\nKey file size: (%d) \n", key_size);

	if(key_size != BROADCAST_KEY_SIZE)
	{
		printf("\n\n^^**^^ FAILURE: key_size != BROADCAST_KEY_SIZE ^^**^^\n\n");
		fclose(keyF);
		return 1;
	}

	fclose(keyF);
	



	//open file for reading
	keyF = fopen(encKFile, "r");

	


	/* Read and display key */
	counter = fread(broadcast_key, 1, BROADCAST_KEY_SIZE, keyF);
	
	
	fclose(keyF);

	if(counter != BROADCAST_KEY_SIZE)
	{
		printf("\n\n^^**^^ FAILURE: counter != BROADCAST_KEY_SIZE ^^**^^\n\n");
		return 1;
	}


	if(!release)
	{ 
		printf("-------------------------------------------------------------------------\n");
		printf("broadcast key: \n");
		for(int i=0; i<BROADCAST_KEY_SIZE; i++) printf("%02x ", broadcast_key[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}
	
	
	hash_process(&state, broadcast_key, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{ 
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//reconstruct key
	for(int i=0; i<16; i++) actual_key[i] = hash[2*i]^hash[(2*i)+1];
	if(!release)
	{ 
		printf("-------------------------------------------------------------------------\n");
		printf("Reconstructed key: \n");
		for(int i=0; i<16; i++) printf("%02x ", actual_key[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	return 0;
}

int encrypt_data(int data_length)
{

	OAES_RET result;
	OAES_CTX * ctx;

	unsigned char current_IV[block_len];
	unsigned char temp[block_len];

	if(!release) printf("This is encrypt_data() function \n");

	if(!release)
	{
		printf("data_length: %d \n", data_length);

		printf("-------------------------------------------------------------------------\n");
		printf("data to be encrypted: \n");
		for(int i=0; i<data_length; i++) printf("%02x ", data[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");

		printf("-------------------------------------------------------------------------\n");
		printf("using this actual_key: \n");
		for(int i=0; i<16; i++) printf("%02x ", actual_key[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
		
	}


	//1- set random IV
	for(int i=0; i<block_len; i++) first_IV[i] = get_rand();
	if(!release)
	{
		printf("first_IV:");
		for(int d=0; d<block_len; d++) printf("%02x ", first_IV[d]);
		printf("\n");
	}

	


	//2- create ctx and set key
	ctx = oaes_alloc();
	oaes_set_option((oaes_ctx *)ctx, OAES_OPTION_ECB, NULL );
	result = oaes_key_import_data(ctx, actual_key, block_len);
	if(result != 0)
	{	
		printf("Failure: Result of oaes_key_import_data: %d \n",(int) result);
		return 1;
	}
	
	


	

	if(!release) printf("In encrypt_data(), data_length: %d \n", data_length);

	//3-encrypt data iteratively block by block
	//copy first_IV into current_IV
	memcpy(current_IV, first_IV, block_len);	

	//n = data_length/block_len (block_len = 16)
	int num_of_blocks = data_length/block_len;
	for(int n=0; n<num_of_blocks; n++)
	{
		//a- temp = 16 bytes from msg/hdr
		memcpy(temp, &data[n*block_len], block_len);
		if(!release)
		{
			printf("## before anything, temp:");
			for(int i =0; i<block_len; i++) printf("%02x ", (int)temp[i]);        
			printf("\n");
		}


		
		if(!release)
		{
			printf("current_IV:");
			for(int d=0; d<block_len; d++) printf("%02x ", current_IV[d]);
			printf("\n");
		}
		

		//b- xor temp with current_IV
		for(int i=0; i<block_len; i++) temp[i] = temp[i]^current_IV[i];

		if(!release)
		{
			printf("## [after XORing with current_IV] temp:");
			for(int d=0; d<block_len; d++) printf("%02x ",(int)temp[d]);
			printf("\n");
		}

		//c- encrypt temp
		result = oaes_encrypt_block_n(ctx, temp, block_len);
		if(result != 0)
		{
			printf("## Result of 2nd half random_2 oaes_encrypt_block: %d \n",(int) result);
			return 1;
		}


		if(!release)
		{
			printf("## (after encryption) temp:");
			for(int d=0; d<block_len; d++) printf("%02x ",(int)temp[d]);
			printf("\n");
		}

		//d- copy temp into data:
		memcpy(&data[n*block_len], temp, block_len);

		//e- update current_IV
		memcpy(current_IV, temp, block_len);
	}


	//4- write IV||encrypted data to file.
	FILE *emsgF = fopen(e_msgFile, "w");
	//4-a- write IV to file
	int write_counter = fwrite(first_IV, 1 , block_len, emsgF);
	if(!release) printf("write_counter = (%d) \n", block_len);
	if(write_counter != block_len)
	{
		printf("\nFAILURE: writing encrypted message file: %s.\n", e_msgFile);
		fclose(emsgF);
		return 1;
	}
	//4-b- write encrypted data to file
	write_counter = fwrite(data, 1 , data_length, emsgF);
	if(!release) printf("write_counter = (%d) \n", write_counter);
	if(write_counter != data_length)
	{
		printf("\nFAILURE: writing encrypted message file: %s.\n", e_msgFile);
		fclose(emsgF);
		return 1;
	}
	

	//5- close file
	fclose(emsgF);
}



int decrypt_data(int data_length)
{

	
	OAES_RET result;
	OAES_CTX * ctx;

	unsigned char current_IV[block_len];
	unsigned char next_IV[block_len];
	unsigned char temp[block_len];

	if(!release) printf("This is decrypt_data() function \n");

	if(!release)
	{
		printf("data_length: %d \n", data_length);

		printf("-------------------------------------------------------------------------\n");
		printf("data to be decrypted: \n");
		for(int i=0; i<data_length; i++) printf("%02x ", data[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");

		printf("-------------------------------------------------------------------------\n");
		printf("using this actual_key: \n");
		for(int i=0; i<block_len; i++) printf("%02x ", actual_key[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");	
	}


	//1- get IV
	memcpy(first_IV, data, block_len);
	if(!release)
	{
		printf("first_IV:");
		for(int d=0; d<block_len; d++) printf("%02x ", first_IV[d]);
		printf("\n");
	}

	data_length = data_length - block_len;

	for(int i=0; i<data_length; i++) data[i] = data[i+block_len];
	if(!release)
	{
		printf("After removing IV, data:");
		for(int d=0; d<data_length; d++) printf("%02x ", data[d]);
		printf("\n");
	}
	


	//2- create ctx and set key
	ctx = oaes_alloc();
	oaes_set_option((oaes_ctx *)ctx, OAES_OPTION_ECB, NULL );
	result = oaes_key_import_data(ctx, actual_key, block_len);
	if(result != 0)
	{	
		printf("Failure: Result of oaes_key_import_data: %d \n",(int) result);
		return 1;
	}
	

	if(!release) printf("In decrypt_data(), data_length: %d \n", data_length);

	//3-decrypt data iteratively block by block
	//copy first_IV into current_IV
	memcpy(current_IV, first_IV, block_len);	

	//n = data_length/block_len (block_len = 16)
	int num_of_blocks = data_length/block_len;
	for(int n=0; n<num_of_blocks; n++)
	{
		//a- temp = 16 bytes from msg/hdr
		memcpy(temp, &data[n*block_len], block_len);
		if(!release)
		{
			printf("## before decryption, temp:");
			for(int i =0; i<block_len; i++) printf("%02x ", (int)temp[i]);        
			printf("\n");
		}

		//b- copy current cipher as next_IV
		memcpy(next_IV, temp, block_len);

		//c- decrypt temp
		result = oaes_decrypt_block_n(ctx, temp, block_len);
		if(result != 0)
		{
			printf("## oaes_decrypt_block_n: %d \n",(int) result);
			return 1;
		}


		if(!release)
		{
			printf("## (after decryption) temp:");
			for(int d=0; d<block_len; d++) printf("%02x ",(int)temp[d]);
			printf("\n");
		}


		
		if(!release)
		{
			printf("current_IV:");
			for(int d=0; d<block_len; d++) printf("%02x ", current_IV[d]);
			printf("\n");
		}
		

		//d- xor temp with current_IV
		for(int i=0; i<block_len; i++) temp[i] = temp[i]^current_IV[i];

		if(!release)
		{
			printf("## [after XORing with current_IV] temp:");
			for(int d=0; d<block_len; d++) printf("%02x ",(int)temp[d]);
			printf("\n");
		}

		

		//e- copy temp into data:
		memcpy(&data[n*block_len], temp, block_len);

		//f- update current_IV
		memcpy(current_IV, next_IV, block_len);
	}


	if(!release)
	{
		printf("After decryption, data_length: %d \n", data_length);

		printf("-------------------------------------------------------------------------\n");
		printf("Decrypted data: \n");
		for(int i=0; i<data_length; i++) printf("%02x ", data[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//4- read actual data length (without padding)
	int actual_data_length = 0;
	actual_data_length = data[0];
	actual_data_length = actual_data_length << 8;
	actual_data_length = actual_data_length | data[1];

	if(!release) printf("actual_data_length: %d \n", actual_data_length);
	
	if(actual_data_length > MAX_SIZE)
	{
		printf("\nFAILURE: actual_data_length > MAX_SIZE - something must be wrong, return false. \n");
		return 1;
		
	}

	if(!release)
	{
		

		printf("-------------------------------------------------------------------------\n");
		printf("original message: \n");
		for(int i=0; i<actual_data_length; i++) printf("%02x ", data[2+i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//5- open and write decrypted message to file
	FILE *dmsgF = fopen(d_msgFile, "w");
	int write_counter = fwrite(&data[2], 1 , actual_data_length, dmsgF);
	if(!release) printf("write_counter = (%d) \n", write_counter);
	if(write_counter != actual_data_length)
	{
		printf("\nFAILURE: writing encrypted message file: %s.\n", e_msgFile);
		fclose(dmsgF);
		return 1;
	}
	

	//6- close file
	fclose(dmsgF);


	if(!release) printf("\n\nDecryption is successful.\n\n");	

	return 0;
}

int encrypt_file()
{

	if(!release) printf("This is encrypt_file() \n");

	//1- check if msg.txt and encK.txt files exist
	FILE *msgF = fopen(msgFile, "r");
	FILE *keyF = fopen(encKFile, "r");

	//check if the files exist and successfully opened.
	if((msgF == NULL) || (keyF == NULL))
	{
		printf("\n\n^^**^^ FAILURE: you need two files: encK.txt and msg.txt ^^**^^\n\n");
		fclose(msgF);
		fclose(keyF);
		return 1;
	}

	//no need to use it for now
	fclose(keyF);



	//2- find the length of msg.txt
	
	if(fseek(msgF, 0, SEEK_END))
	{
		printf("\n\n^^**^^ FAILURE: fseek(msgF, 0, SEEK_END) returned false ^^**^^\n\n");
		fclose(msgF);
		return 1;
	}

	int msg_size = ftell(msgF);

	if(!release) printf("\n\nMsg file size: (%d) \n", msg_size);

	//close message file
	fclose(msgF);


	//3- check if message is bigger than the array.
	if(msg_size > (MAX_SIZE - 2))
	{
		printf("\n\n^^**^^ FAILURE: msg_size >  MAX_SIZE ^^**^^\n\n");
		return 1;
	}


	//4- open (again) and read message into data[]
	msgF = fopen(msgFile, "r");
	int actual_data_length = fread(data, 1, msg_size, msgF);
	
	//close message file
	fclose(msgF);

	if(actual_data_length != msg_size)
	{
		printf("\n\n^^**^^ actual_data_length != msg_size ^^**^^\n\n");
		return 1;	
	}



	//5- re-order bytes in data[] by adding two bytes at the beginning specifying the actual_data_length
	
	int length = actual_data_length + 2;
	if(!release) printf("\n\nlength: (%d) \n", length);

	for(int i=length-1, j=actual_data_length-1; i>1; i--, j--) data[i] = data[j];
	data[0] = actual_data_length >> 8; //MSB
	data[1] = actual_data_length & 0x0000ff; //LSB

	if(!release) printf("data[]: ");
	if(!release) for(int i=0; i<length; i++)printf("%02x ", data[i]);
	if(!release) printf("\n");
	
	//6- if (actual_data_length + (2 length bytes))%16 != 0, then add random dummy characters
	if(length%16 != 0)
	{

		if(!release) printf("(length is not mod of 16 ==> Add padding");

	
		

		int padding_length = 16 - (length%16);

		for(int i=length; i<length + padding_length; i++) data[i] = get_rand();
		length = length + padding_length;
		if(!release) printf("\n\nNew length: (%d) \n", length);
		
		if(!release) printf("New data[]: ");
		if(!release) for(int i=0; i<length; i++)printf("%x ", data[i]);
		if(!release) printf("\n");
	}


	//7- extract key from encK.txt and put extracted key in actual_key[]
	extract_key();

	
	//encrypt data[]
	if(encrypt_data(length))
	{
		printf("\n\n^^**^^ Failure: in encrypt_data() ^^**^^\n\n");
		return 1;
	}



	
	if(!release) printf("Encryption is successful, file should contain (IV||actual length||data||padding)\n\n");	
  	

	return 0;
}



int decrypt_file()
{

	if(!release) printf("This is decrypt_file() \n");


	//1- check if emsg.txt and encK.txt files exist
	FILE *rmsgF = fopen(r_msgFile, "r");
	FILE *keyF = fopen(encKFile, "r");

	//check if the files exist and successfully opened.
	if((rmsgF == NULL) || (keyF == NULL))
	{
		printf("\n\n^^**^^ FAILURE: you need two files: encK.txt and received_msg.txt ^^**^^\n\n");
		if(rmsgF == NULL) printf("\n\n^^**^^ %s file does not exist ^^**^^\n\n", r_msgFile);
		if(keyF == NULL) printf("\n\n^^**^^ %s file does not exist ^^**^^\n\n", encKFile);
		fclose(rmsgF);
		fclose(keyF);
		return 1;
	}

	//no need to use it for now
	fclose(keyF);



	//2- find the length of msg.txt
	if(fseek(rmsgF, 0, SEEK_END))
	{
		printf("\n\n^^**^^ FAILURE: fseek(rmsgF, 0, SEEK_END) returned false ^^**^^\n\n");
		fclose(rmsgF);
		return 1;
	}

	int rmsg_size = ftell(rmsgF);

	if(!release) printf("\n\nRMsg file size: (%d) \n", rmsg_size);

	//close message file
	fclose(rmsgF);


	//3- check if message is bigger than the array.
	if(rmsg_size > MAX_SIZE)
	{
		printf("\n\n^^**^^ FAILURE: rmsg_size >  MAX_SIZE ^^**^^\n\n");
		return 1;
	}

	//4- minimum length of rmsg is 32 (IV||16-byte cipher)
	if(rmsg_size < 32)
	{
		printf("\n\n^^**^^ FAILURE: rmsg_size < 32 ^^**^^\n\n");
		return 1;
	}

	//4- check if rmsg is not multiple of 16
	if(rmsg_size%16 != 0)
	{
		printf("\n\n^^**^^ FAILURE: rmsg_size is not multiple of 16 ^^**^^\n\n");
		return 1;
	}


	//5- open (again) and read message into data[]
	rmsgF = fopen(r_msgFile, "r");
	fread(data, 1, rmsg_size, rmsgF);
	
	//close message file
	fclose(rmsgF);


	//6- extract key from encK.txt and put extracted key in actual_key[]
	extract_key();

	
	//decrypt data[]
	if(decrypt_data(rmsg_size))
	{
		printf("\n\n^^**^^ Failure: in decrypt_data() ^^**^^\n\n");
		return 1;
	}



	
	if(!release) printf("Decryption is successful, clear message is stored in dmsg.txt\n\n");	

	return 0;
}

// main
int main(int argc, char **argv)
{
	option = (argc > 1) ? atoi(argv[1]) : 0;
	release = (argc > 2) ? atoi(argv[2]) : 0;

	

	if(!release) printf("option: %d \n", option);
	if(!release) printf("release: %d \n", release);


	if(!release) printf("\n\n************************************************************************ \n"); 
	if(!release) printf("This program is encrypts and decrypts files using cryptonote oaes library.\n");
	if(!release) printf("************************************************************************ \n");

	
	//initialize rand() in case it gets used
	initialize_rand();


	if((option != mode_enc) && (option != mode_dec))
	{
		printf("Invalid option, select 1 for encryption and 2 for decryption \n");
		return 1;
	}

	current_mode = option;
	
	if(current_mode == mode_enc)
	{
		return encrypt_file();
	}
	else
	{
		return decrypt_file();
	}
		 
	

    	return 0;
}


#if 0

//This function extracts a hidden msg (if any) given a key, c, and r "random" numbers.
void extract(uint8_t *key, uint8_t *c, uint8_t *r)
{
	int k_len = 16;
	int block_len = 16;
	uint8_t extracted_IV[16];

	OAES_RET result;
	OAES_CTX * ctx;

	// create ctx and set key
	ctx = oaes_alloc();
	oaes_set_option((oaes_ctx *)ctx, OAES_OPTION_ECB, NULL );
	result = oaes_key_import_data(ctx, key, k_len);
	if(result != 0){
		printf("Result of oaes_key_import_data: %d - Error, return \n",(int) result);
		return;
	}

	//1- extract IV
	memcpy(extracted_IV, c, block_len);

	//2- decrypt IV
	result = oaes_decrypt_block_n(ctx, extracted_IV, block_len);
	if(result != 0){
		printf("Result of 1st half of r oaes_decrypt_block: %d - Error, return \n",(int) result);
		return;
	}

	
	printf("Decrypted IV: ");
    	for(int i=0; i<block_len; i++) printf("%02x", extracted_IV[i]);
    	printf("\n");

	//3- check if last 8 bytes are equal to start_pattern (0's)
	int start_pattern = 1;
	for(int d=0; d<8; d++)
	{
		if(extracted_IV[8+d] != 0) start_pattern = 0;
	}

	
	if(start_pattern)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("Start pattern was successfully found.\n");
		
		//4- extract IV (again)
		memcpy(extracted_IV, c, block_len);
		printf("IV: ");
	    	for(int i=0; i<block_len; i++) printf("%02x", extracted_IV[i]);
	    	printf("\n");

		//5- decrypt 1st half of r
		result = oaes_decrypt_block_n(ctx, r, block_len);
		if(result != 0){
			printf("Result of 1st half of r oaes_decrypt_block: %d - Error, return \n",(int) result);
			return;
		}
	
		//6- xor decrypted 1st half of r with extracted IV
		for(int i=0; i<block_len; i++) r[i] ^= extracted_IV[i];

		printf("Hidden message is (16 bytes): ");
	    	for(int i=0; i<block_len; i++) printf("%c ", r[i]);
	    	printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}
	else
	{
		printf("## Unable to extract any hidden message ##\n");
	
	}

	return;
}

//this function is copied from the Bytecoin project
void hash_process(union hash_state *state, const uint8_t *buf, size_t count) {
	keccak1600(buf, (int)count, (uint8_t*)state);
}


//This function reads the file contains the two random numbers: c, and r.
//Sets the key, and calls extract(..) to extract the hidden msg.
void extract_hidden_msg()
{
	uint8_t c[32];
	uint8_t r[32];

	uint8_t buffer[2000];
    	int counter = 0;
    	char fileName[7]= "cr.txt\0";
	
	counter = read_hex_file(buffer,crFile);

	if(!counter)
	{	
		printf("Failed to read \"%s\" - make sure c and r in cr.txt\n", crFile);
		return;
	}

	if(counter != 64)
	{
		printf("Invalid length of cr.txt\n");
		return;
	}

	memcpy(c, buffer, 32);
	memcpy(r, buffer+32, 32);
	

	printf("-------------------------------------------------------------------------\n");
	printf("c and r (check if they are found within tx binary): \n");
	printf("c: ");
	for(int i=0; i<32; i++) printf("%02x", c[i]);
	printf("\n");
	printf("r: ");
	for(int i=0; i<32; i++) printf("%02x", r[i]);
	printf("\n");
	printf("-------------------------------------------------------------------------\n");

	uint8_t key[16];
	int k_len = 16;
	//use a 16-byte key: {14,15,...,29}
	for(int i=0; i<k_len; i++) key[i] = 14 + i;

	extract(key,c,r);
}


//This function reads in the file containing the tx binary, and hashes it using hash_process()
void hash_tx()
{
	
	uint8_t buffer[2000];
	int counter = 0;
	counter = read_hex_file(buffer,txFile);

	if(!counter) printf("Failed to read \"%s\" - make sure tx binary in \"%s\"\n", txFile, txFile);
	/*
	printf("------------------------------------------------\n");
	printf("tx size: %d and tx binary is: \n", counter);
	for(int i=0; i<counter; i++) printf("%02x", buffer[i]);
	printf("\n------------------------------------------------\n");
	*/
	unsigned char hash[HASH_SIZE];
	union hash_state state;
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	printf("-------------------------------------------------------------------------\n");
	printf("hash of the given tx (check if it corresponds to paper and chain explorer): \n");
	for(int i=0; i<HASH_SIZE; i++) printf("%02x", hash[i]);
	printf("\n");
	printf("-------------------------------------------------------------------------\n");

	return;
}
#endif
