#!/bin/bash

#printf $"create and send transaction.\n"
#printf $"1)Create transaction.\n"

whole_string=$(curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "create_transaction",
  "params": {
    "transaction": {
      "anonymity": 29,
      "payment_id": "",
      "transfers": [
        {
          "address": "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6",
          "amount": 100000000
		    
        }
      ]
    },
    "spend_addresses": [
      "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6"
    ],
    "change_address": "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6",
    "optimization": "minimal"
  }
}')

#echo $whole_string

#echo "----------------"

tx_binary=$(echo $whole_string | jq '.result.binary_transaction')

#echo $tx_binary



#printf $"2)Transfer payment.\n"



send_string=$(curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
	"jsonrpc": "2.0", 
	"id": "0", 
	"method": "send_transaction", 
	"params": { "binary_transaction":'$tx_binary'}}')
#echo $send_string







