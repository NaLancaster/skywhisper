#!/bin/bash
# declare STRING variable
#STRING="Hello World"
#print variable on a screen
#echo $STRING

#http://<127.0.0.81>:<8070>/json_rpc


curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "get_addresses",
  "params": {}
}'

printf $"\n"
printf $"\n"

curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "get_view_key_pair",
  "params": {}
}'

printf $"\n"
printf $"\n"

curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "get_balance",
  "params": { "height_or_depth": -10 }
}'

printf $"\n"
