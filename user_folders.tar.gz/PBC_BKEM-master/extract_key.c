//this file extracts encryptiong key given three files: 
//1) pk.txt (public key) 
//2) pr.txt (private) 
//3) HDR.txt (HDR)

#include "bkem.h"


#define print_function 0


char public_key_file[16] = "keys/PK.txt";
char hdr_file[16] = "keys/HDR.txt";
char encK_file[16] = "keys/encK.txt";

int release;


bkem_global_params_t gps;	
//sys: a structure contains two elements: 1) a structure holding the public key PK. 2) an array of N private keys.
//PK is itself a structure as shown in bkem.h 
//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
bkem_system_t sys; 


void print_elements()
{

	printf("PK: \n");
	element_printf("sys->PK->g = %B\n", sys->PK->g);
	for(int i=0; i<2*gps->B;i++)
	{
		printf("sys->PK->g_i[%d] = ", i);
		element_printf(" %B\n", sys->PK->g_i[i]);
	}

	unsigned char v_i_bytes[element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{

		len_v = element_to_bytes(v_i_bytes, sys->PK->v_i[i]);

		printf("sys->PK->v_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", v_i_bytes[j]);
		printf("\n");

		//element_printf(" %B\n", i, sys->PK->v_i[i]);
	}
	

	printf("----------------------------------------------------------------\n\n");

	unsigned char d_i_bytes[element_length_in_bytes(sys->d_i[0])];

	printf("Private keys: \n");
	
	int len_d = 0;
	for(int i=0; i<gps->N; i++)
	{	
		len_d = element_to_bytes(d_i_bytes, sys->d_i[i]);

		printf(" sys->d_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", d_i_bytes[j]);
		printf("\n");
		//element_printf("%B\n", i, sys->d_i[i]);
	} 
	printf("----------------------------------------------------------------\n\n");
		
	
}

int main(int argc, const char *argv[]) {

	unsigned int c,k,j;
	
	FILE *param = fopen("/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/a.param", "r");
	char buf[4096];
	fread(buf, 1, 4096, param);

	

	if(argc < 6)
	{
		printf("\n\n\nNot enough number of arguments in extract_key, provide: number of users + user index + private key file + subscribers list file + release\n\n\n");
		return 1;
	}

	release = atoi(argv[5]);

	if(!release) printf("\nThis is extract_key\n");

	if(!release) printf("numbre of users: %s , user index: %s, subscribers file: %s , private file: %s , release: %s \n", argv[1], argv[2], argv[3],argv[4], argv[5]);

	
	


	
	setup_global_system(&gps, (const char*) buf, atoi(argv[1]));

	if(!release) printf("Global System parameters: N = %d, A = %d, B = %d\n\n", gps->N, gps->A, gps->B);

	
	setup(&sys, gps);
    
	

	if(!release) printf("\n\nFirst, read subscribers info from: %s\n", argv[3]);

	//read subscribers list and set c and S accordingly
	FILE *fp = fopen(argv[3], "r");
	if(fp == NULL)
	{
		printf("\n\n\nNOT able to open subscribers file: %s \n\n\n", argv[3]);
		return 1;
	}

	//read subscribers' file content
	char indices[gps->N];
	int counter = fread(indices,1,gps->N, fp);
	if(!release) printf("\nNumber of read bytes from subscribers file: %d \n", counter);
	c = 0;	
	int S[c];
	
	for (k = 0; k<counter; ++k) {
		if(indices[k] != 99)	//omit indices that are padding
		{	
			S[c++] = indices[k];
		}
	}
	
	
	if(!release) 
	{
		printf("\nc = %d, and the resulting set S = [ ",c);
		for(int k=0; k<c; k++) printf("%d ", S[k]);
		printf("]\n\n");
	}

	keypair_t keypair;
	get_encryption_key(&keypair, S, c, sys, gps); //--> keypair->HDR will be used to store re-constructed HDR elements
						      //--> keypair->K will store the extracted key.
	//----------------------------------------------------------------------------------------



	

	if(!release) printf("\n\nSecond, read public key from: %s and re-construct public key (sys->PK).\n", public_key_file);



	
	//open pkfile
	FILE *pkFile = fopen(public_key_file, "r");

	if(pkFile == NULL)
	{
		printf("\n\n\nNOT able to open public key file: %s \n\n\n", public_key_file);
		return 1;
	}


	//1- read and reconstruct sys->PK->g
	unsigned char new_g_bytes[128];
	
	counter = fread(new_g_bytes,1,128,pkFile);
	//set sys->PK->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(sys->PK->g, new_g_bytes);

	//2- read and reconstruct sys->PK->g_i
	unsigned char new_g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//read from file
		counter = fread(new_g_i_bytes[i],1,128,pkFile);

		//initialize public_key->g_i[i] as sys->PK->g_i[i]
		//element_init_same_as(public_key->g_i[i],sys->PK->g_i[i]);

		//set sys->PK->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(sys->PK->g_i[i], new_g_i_bytes[i]);
		//printf("For sys->PK->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	//3- read and reconstruct sys->PK->v_i
	unsigned char new_v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];
	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//read from file
		counter = fread(new_v_i_bytes[i],1,128,pkFile);
		
		//initialize public_key->v_i[i] as sys->PK->v_i[i]
		//element_init_same_as(public_key->v_i[i],sys->PK->v_i[i]);

		//set sys->PK->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(sys->PK->v_i[i], new_v_i_bytes[i]);
		//printf("For sys->PK->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}


	//close pkfile
	fclose(pkFile);

	if(!release) printf("\nPublic key is read and reconstructed in sys->PK");

	
	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------
	
	
	if(!release) printf("\n\nThird: read HDR from  %s\n", hdr_file);
	 
	//printf("Create and open a file \n");
	FILE *hdrfile; 

	// open file for writing 
	hdrfile = fopen (hdr_file, "r");  

	if(hdrfile == NULL)
	{
		printf("\n\n\nNOT able to open HDR file: %s \n\n\n", hdr_file);
		return 1;
	}
	

	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	

	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		counter = fread(read_HDR_bytes[i],1,128,hdrfile);
		if(!release) printf("For read_HDR_bytes[%d], the number of read bytes: %d \n", i, counter);
	}

	fclose(hdrfile);


	//re-construct the HDR elements and store in keypair->HDR[i]
	

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//set keypair->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(keypair->HDR[i], read_HDR_bytes[i]);
		if(!release) printf("For keypair->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}


	if(!release) printf("\nHDR is read and reconstructed in keypair->HDR");

	//----------------------------------------------------------------------------------------
	//----------------------------------------------------------------------------------------

	char *index_chars = argv[2];
	int index = (index_chars[0] - 48)*10 + (index_chars[1] - 48);


	
	if(!release) printf("\n\nFourth: read private key from: %s \n", argv[4]);

	// open file for writing 
	FILE *privateFile = fopen (argv[4], "r");  

	if(privateFile == NULL)
	{
		printf("\n\n\nNOT able to open private key file: %s \n\n\n", argv[4]);
		return 1;
	}

	//read private key
	unsigned char read_private[element_length_in_bytes(sys->d_i[index])];
	counter = fread(read_private,1,128,privateFile);
	if(!release) printf("\nFor read_private, the number of read bytes: %d \n", counter);


	
	//create a new element_t to contain re-constructed private key
	element_t private_key;
	element_init_G1(private_key, gps->pairing);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(private_key/*new_struct->d_i[index]*/, read_private);
	if(!release) printf("Private key is reconstructed, len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	if(!release)
	{
		printf("Reconstructed private key for this user with index: %d", index);
		element_printf(" %B \n", private_key);

		print_elements();
	}
	


	if(!release) printf("\n\nFifth: use re-constructed HDR and private key to retrieve encryption key K, c=%d\n", c);

		
	get_decryption_key(/*extracted K*/keypair->K, gps, S, c, index, /*read private key*/private_key, 
				/*read HDR*/keypair->HDR, /*read pk*/sys->PK);
	

	
	if(!release) element_printf("\nThe retrieved encryption key: keypair->K = %B\n", keypair->K);


	if(!release) printf("Write retrieved key to: %s\n", encK_file);

	//create an array of arrays to hold encryption key bytes
	unsigned char encK_Bytes[element_length_in_bytes(keypair->K)];

	int len_encK = element_to_bytes(encK_Bytes, keypair->K);
	if(!release) printf("len_encK: %d \n", len_encK);

	//create a file encK_file and write key to it.
	FILE *kf = fopen(encK_file, "w");
	fwrite(encK_Bytes, len_encK, 1, kf);
	


	fclose(kf);



}




