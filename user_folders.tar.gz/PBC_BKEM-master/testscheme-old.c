#include "bkem.h"


#define testing_conversion 0
#define testing_writing_user_files 0
#define store_pk_hdr_pr 1
#define write_pk_to_file 0
#define reconstruct_from_files 0


int in_set(int *Set, int length, int value)
{

	int found = 0;
	for(int i=0; i<length; i++)
	{
		if(Set[i] == value)
		{
			found = 1;
			break;
		}
	}
	return found;
}


int main(int argc, const char *argv[]) {

	FILE *param = fopen("a.param", "r");
	char buf[4096];
	fread(buf, 1, 4096, param);

	printf("\nThis is testscheme...\n");
	printf("\nSystem setup Key\n\n");

	bkem_global_params_t gps;
	setup_global_system(&gps, (const char*) buf, (argc > 1) ? atoi(argv[1]) : 256);

	printf("Global System parameters: N = %d, A = %d, B = %d\n\n", gps->N, gps->A, gps->B);

	//sys: a structure contains two elements: 1) a structure holding the public key PK. 2) an array of N private keys.
	//PK is itself a structure as shown in bkem.h 
	//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	bkem_system_t sys; 
	setup(&sys, gps);
    
	printf("\nTesting system\n\n");

	
    
	unsigned int c,k,j;
	/*
	Test subset S with continuous indices, i.e. S = {0,1} or S = {0,1,2,3} , etc
	*/   
	int continuous_test = 1; 	
	for (c = 2; c <= gps->N; c*=2) {
		

		int S[c];
		printf("\nTesting with S = [ ");
		for (k = 0; k < c; ++k) {
		    S[k] = k;
		    printf("%d ", k);
		}
		printf("]\n\n");

		keypair_t keypair;
		get_encryption_key(&keypair, S, c, sys, gps);


		element_t K;


		for (j = 0; j < gps->N; ++j) {
		    get_decryption_key(K, gps, S, c, j, sys->d_i[j], keypair->HDR, sys->PK);
		    if (!element_cmp(keypair->K, K)) {
			if (j >= c)
			{
				printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
				continuous_test = 0;
			}
			/*if(c == 2)
			{
				printf("With c == %d, and when user index = (%d), \n", c, j);
				element_printf("the private key  = %B\n", sys->d_i[j]);
				element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
			}*/
			          
		    } else {
			if (j < c)
			{
			    	printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
				continuous_test = 0;
			}
		    }
		    element_clear(K);
		}
		free(keypair);

	}

	if(continuous_test)
	{
		printf("First test: S with continuous indices PASSED successfully\n");
	}
	else
	{
		printf("First test: S with continuous indices FAILED miserably\n");
	}


	/*
	Test subset S with non-continuous indices, i.e. S = {0,3} or S = {0,1,5} , etc
	*/ 
	int non_continuous_test = 1;
	time_t t;
	int r;
	/* Intializes random number generator */
   	srand((unsigned) time(&t));
	for (c = 1; c <= gps->N; c++) {
		

		int S[c];
		int actual_length = 0;
		//int not_empty = 0;
		for (k = 0; k < c; ++k)
		{
			r = rand()%10;
			//printf("for k: %d, r: %d \n", k, r);
			if(r > 5)
			{
				S[actual_length] = k;
				actual_length++;
			}
		    
			
		}
		
		//printf("for c: %d, actual_length: %d \n", c, actual_length);

		if(actual_length)
		{

			printf("\nTesting with S = [ ");
			for (k = 0; k < actual_length; ++k)
			{
				printf("%d ", S[k]);
			}
			printf("]\n\n");

			keypair_t keypair;
			get_encryption_key(&keypair, S, actual_length, sys, gps);


			element_t K;


			for (j = 0; j < gps->N; ++j) {
			    get_decryption_key(K, gps, S, actual_length, j, sys->d_i[j], keypair->HDR, sys->PK);	
			    if (!element_cmp(keypair->K, K)) {
				printf("Non-continuous test, decryption Key for [User %d] matches\n", j); 
				if (!in_set(S,actual_length,j))
				{
					printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
					non_continuous_test = 0;
				}
				/*if(c == 2)
				{
					printf("With c == %d, and when user index = (%d), \n", c, j);
					element_printf("the private key  = %B\n", sys->d_i[j]);
					element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
				}*/
					  
			    } else {
				if (in_set(S,actual_length,j))
				{
				    	printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
					non_continuous_test = 0;
				}
			    }
			    element_clear(K);
			}
			free(keypair);
		}

	}

	if(non_continuous_test)
	{
		printf("First test: S with non-continuous indices PASSED successfully\n");
	}
	else
	{
		printf("First test: S with non-continuous indices FAILED miserably\n");
	}



	printf("\n\n\nMy test is beginning...\n\n\n");




#if write_pk_to_file

	printf("\n\n\nCheck if a PK can be transferred to bytes and then re-created from bytes ***\n");
	printf("\nFirst, check if sys->PK->g can be read in bytes and then re-created from bytes\n");

	/*******************************************************************************************
	This structure test_struct is used to test the ability of setting/storing private keys and PK
				-- try to use smaller structure to store PK --
	********************************************************************************************/
	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for private keys d_i's
	new_struct->d_i = pbc_malloc(gps->N * sizeof(struct element_s));

	
	//set new_struct->PK->g using the bytes read in g_bytes
	element_init_same_as(new_struct->PK->g,sys->PK->g);

	for (int i = 0; i < gps->N; ++i) 
	{
		//printf("i: %d \n", i);
		element_init_same_as(new_struct->d_i[i],sys->d_i[i]);
		element_set(new_struct->d_i[i],sys->d_i[i]);
	}
	/******************************************************************************************/

	//element_printf("The original PK->g is = %B\n", sys->PK->g);


	unsigned char *g_bytes;
	
	int len_g = element_length_in_bytes(sys->PK->g); 
	//printf("Length of g from length function is: %d \n", len_g);
	g_bytes = (unsigned char *) malloc(len_g);
	int len_g1 = element_to_bytes(g_bytes, sys->PK->g);
	//printf("Length of g from conversion function is: %d \n", len_g1);
	/*
	printf("\nRead g_bytes in bytes = [ ");
	for (int i = 0; i < len_g1; ++i) {
	    printf("%d ", g_bytes[i]);
	}
	printf("]\n\n");
	*/
	
	
	//set new_struct->PK->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(new_struct->PK->g, g_bytes);
	//printf("len_set_g (element_from_bytes): %d \n", len_set_g);

	//element_printf("The recreated PK->g for bytes: g_bytes = %B\n", new_struct->PK->g);

	if(!element_cmp(new_struct->PK->g, sys->PK->g))
	{
		printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->PK->g != sys->PK->g *****\n");
	}

	printf("\nSecond, check if sys->PK->g_i can be read in bytes and then re-created from bytes\n");
	unsigned char g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len = 0;
	for(int i=0; i<2*gps->B;i++)
	{
		//g_i_bytes[i] = (unsigned char *) malloc(element_length_in_bytes(sys->PK->g_i[i]));
		len = element_to_bytes(g_i_bytes[i], sys->PK->g_i[i]);

		/*printf("\nRead g_i_bytes[%d] in bytes = [ ",i);
		for (int t = 0; t < len; ++t) {
		    printf("%d ", g_i_bytes[i][t]);
		}
		printf("]\n\n");*/
	}

	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//initialize new_struct->PK->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(new_struct->PK->g_i[i],sys->PK->g_i[i]);

		//set new_struct->PK->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(new_struct->PK->g_i[i], g_i_bytes[i]);
		printf("For new_struct->PK->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	int successful = 1;
	for(int i=0; i<2*gps->B; i++)
	{
		if(!element_cmp(new_struct->PK->g_i[i],sys->PK->g_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->g_i[%d] != sys->PK->g_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->g_i[i] == sys->PK->g_i[i] for all 2*gps->B = %d *****\n", 2*gps->B);

	
	printf("\nThird, check if sys->PK->v_i can be read in bytes and then re-created from bytes\n");
	unsigned char v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{
		len_v = element_to_bytes(v_i_bytes[i], sys->PK->v_i[i]);
	}


	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//initialize new_struct->PK->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(new_struct->PK->v_i[i],sys->PK->v_i[i]);

		//set new_struct->PK->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(new_struct->PK->v_i[i], v_i_bytes[i]);
		printf("For new_struct->PK->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}

	successful = 1;
	for(int i=0; i<gps->A; i++)
	{
		if(!element_cmp(new_struct->PK->v_i[i],sys->PK->v_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->v_i[%d] != sys->PK->v_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->v_i[i] == sys->PK->v_i[i] for all gps->A = %d *****\n", gps->A);
#endif


#if store_pk_hdr_pr

	
	printf("\n\nIn this test, we check the following:\n");
	printf("1) The ability to write PK to file (pk.txt).\n");
	printf("2) The ability to read PK to file.\n");
	printf("3) The ability to write HDR to file (hdr.txt).\n");
	printf("4) The ability to read HDR from file.\n");
	printf("5) The ability to write a private key to file (pr.txt).\n");
	printf("6) The ability to read a private key from file (pr.txt).\n");
	printf("7) ** The ability to retrieve K using HDR and private key from respective files **\n");
	printf("8) Store K in a file, read and reconstruct it, and compare to original \n");

	

	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	printf("\n\n\nFirst, write all elements sys->PK->g to (pk.txt).\n");

	
	//printf("Create and open a file \n");
	FILE *pkFile; 
      
	// open file for writing 
	pkFile = fopen ("pk.txt", "w"); 

	//1- read sys->PK->g and write it to file
	unsigned char *g_bytes;
	int len_g = element_length_in_bytes(sys->PK->g); 
	//printf("Length of g from length function is: %d \n", len_g);
	g_bytes = (unsigned char *) malloc(len_g);
	int len_g1 = element_to_bytes(g_bytes, sys->PK->g);

	fwrite(g_bytes, len_g1, 1, pkFile);
	
	//2- read sys->PK->g_i and write to file
	unsigned char g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len = 0;
	for(int i=0; i<2*gps->B;i++)
	{
		//g_i_bytes[i] = (unsigned char *) malloc(element_length_in_bytes(sys->PK->g_i[i]));
		len = element_to_bytes(g_i_bytes[i], sys->PK->g_i[i]);

		/*printf("\nRead g_i_bytes[%d] in bytes = [ ",i);
		for (int t = 0; t < len; ++t) {
		    printf("%d ", g_i_bytes[i][t]);
		}
		printf("]\n\n");*/


		fwrite(g_i_bytes[i], len, 1, pkFile);
	}

	//3- read sys->PK->v_i and write to file
	unsigned char v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{
		len_v = element_to_bytes(v_i_bytes[i], sys->PK->v_i[i]);
		
		fwrite(v_i_bytes[i], len_v, 1, pkFile);
	}

	fclose(pkFile);

	printf("\n\n\nSecond, read (pk.txt) and re-construct public_key.\n");


	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	pubkey_t public_key;
	public_key = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	public_key->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	public_key->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	
	//set public_key->g using the bytes read in g_bytes
	/*Can you change this to pbc_malloc*/
	element_init_same_as(public_key->g,sys->PK->g);


	
	//open pkfile
	pkFile = fopen("pk.txt", "r");
	int res;

	//1- read and reconstruct public_key->g
	unsigned char new_g_bytes[128];
	
	res = fread(new_g_bytes,1,128,pkFile);
	//set public_key->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(public_key->g, new_g_bytes);

	//2- read and reconstruct public_key->g_i
	unsigned char new_g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//read from file
		res = fread(new_g_i_bytes[i],1,128,pkFile);

		//initialize public_key->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(public_key->g_i[i],sys->PK->g_i[i]);

		//set public_key->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(public_key->g_i[i], new_g_i_bytes[i]);
		//printf("For public_key->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	//3- read and reconstruct public_key->v_i
	unsigned char new_v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];
	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//read from file
		res = fread(new_v_i_bytes[i],1,128,pkFile);
		
		//initialize public_key->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(public_key->v_i[i],sys->PK->v_i[i]);

		//set public_key->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(public_key->v_i[i], new_v_i_bytes[i]);
		//printf("For public_key->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}


	//compare re-constructed public_key to original sys->PK
	int successful = 1;
	if(!element_cmp(public_key->g, sys->PK->g))
	{
		printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
	}
	else
	{
		successful = 0;
		printf("\n\n***** Failure: public_key->g != sys->PK->g *****\n");
	}


	
	for(int i=0; i<2*gps->B; i++)
	{
		if(!element_cmp(public_key->g_i[i],sys->PK->g_i[i]))
		{
			//printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: public_key->g_i[%d] != sys->PK->g_i[%d] *****\n",i,i);
		}
	}

	//if(successful) printf("\n\n***** Success: public_key->g_i[i] == sys->PK->g_i[i] for all 2*gps->B = %d *****\n", 2*gps->B);

	

	for(int i=0; i<gps->A; i++)
	{
		if(!element_cmp(public_key->v_i[i],sys->PK->v_i[i]))
		{
			//printf("\n\n***** Success: public_key->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: public_key->v_i[%d] != sys->PK->v_i[%d] *****\n",i,i);
		}
	}

	//if(successful) printf("\n\n***** Success: public_key->v_i[i] == sys->PK->v_i[i] for all gps->A = %d *****\n", gps->A);
	if(successful) printf("\n\n***** Success: reconstructed public_key == sys->PK *****\n");




	
	

	printf("\n\nThird: create a key pair for c = N (maximum), read HDR, convert HDR to bytes, and then write bytes to hdr.txt\n");
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t keypair;
	get_encryption_key(&keypair, S, c, sys, gps);

	element_t new_K;

	int everything_normal = 1;

	for (j = 0; j < gps->N; ++j) {
	    get_decryption_key(new_K, gps, S, c, j, sys->d_i[j], keypair->HDR, sys->PK);
	    if (!element_cmp(keypair->K, new_K)) {
		if (j >= c)
		{
			printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
			everything_normal = 0;
		}
		          
	    } else {
		if (j < c)
		{
		    	printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
			everything_normal = 0;
		}
	    }
	    element_clear(new_K);
	}

	if(!everything_normal) printf("\n\n**************************** ERROR ******************************\n\n");


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	//convert keypair->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}

	
	//printf("Create and open a file \n");
	FILE *hdrfile; 
      
	// open file for writing 
	hdrfile = fopen ("hdr.txt", "w"); 

	//write HDR to file
	for(int i=0; i<(gps->A + 1);i++)
	{
		fwrite(HDR_bytes[i], 128, 1, hdrfile);
	}

	fclose(hdrfile);

	printf("HDR has been written to file hdr.txt\n");



	int index = 2; //choose user with index 2
	printf("\n\nFourth: take the private key of user:(%d), convert it to bytes, and then write bytes to pr.txt\n", index);


	//convert corresponding private key to bytes
	unsigned char *private_bytes;
	int len_private = element_length_in_bytes(sys->d_i[index]); 
	private_bytes = (unsigned char *) malloc(len_private);
	int len01 = element_to_bytes(private_bytes,sys->d_i[index]);
	printf("Length of private key from conversion function is: %d \n", len01);
		
	//write private key that corresponds with user's index to file
	FILE *privateFile;
	// open file for writing 
	privateFile = fopen ("pr.txt", "w");
	fwrite(private_bytes, len01, 1, privateFile);
	fclose(privateFile);

	
	
	printf("Private key for user:(%d) has been written to file pr.txt\n", index);


	printf("\n\nFifth: read HDR from file and compare to original\n");
	 
      
	// open file for writing 
	hdrfile = fopen ("hdr.txt", "r");  


	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	

	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		res = fread(read_HDR_bytes[i],1,128,hdrfile);
		printf("For read_HDR_bytes[%d], the number of read bytes: %d \n", i, res);
	}

	fclose(hdrfile);


	//re-construct the HDR elements and compare with original HDR.
	//create new key pair: new_kp to store re-constructed HDR elements (and later to store retreived encryption key).
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));
	

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//printf("(A) step: %d \n", i);

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i], keypair->HDR[i]);

		//printf("(B) step: %d \n", i);

		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], read_HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}



	successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i], keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful)
	{
		printf("\n\n***** Success: Read HDR is same as original HDR *****\n");
	}
	else
	{
		printf("\n\n$$$$ Failure: Read HDR is NOT same as original HDR $$$$\n");
	}
	
	printf("\n\nSixth: read private key from file and compare to original\n");

	// open file for writing 
	privateFile = fopen ("pr.txt", "r");  

	//read private key
	unsigned char read_private[element_length_in_bytes(sys->d_i[index])];
	res = fread(read_private,1,128,privateFile);
	printf("\nFor read_private, the number of read bytes: %d \n", res);


	
	//create a new element_t to contain re-constructed private key
	element_t private_key;
	element_init_G1(private_key, gps->pairing);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(private_key/*new_struct->d_i[index]*/, read_private);
	printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: private_key = %B\n", private_key);

	//element_printf("The original private key for bytes: sys->d_i[index] = %B\n", sys->d_i[index]);

	if(!element_cmp(private_key/*new_struct->d_i[index]*/, sys->d_i[index]))
	{
		printf("\n\n***** Success: read private key is same as original for index: (%d) *****\n",index);	
	}
	else
	{
		printf("\n\n$$$$$ Failure: read private key is NOT same as original for index: (%d) $$$$$\n",index);
	}


	printf("\n\nSeventh: use re-constructed HDR and private key to retrieve encryption key K, c=%d\n", c);

	//new_kp->K = get decryption key	
	get_decryption_key(/*new_K*/new_kp->K, gps, S, c, index, /*reconstructed private key*/private_key, 
				/*reconstucted HDR*/new_kp->HDR, /*reconstructed pk*/public_key);
	

	element_printf("The original encryption key: keypair->K = %B\n", keypair->K);
	element_printf("The retrieved encryption key: new_kp->K = %B\n", new_kp->K);


	if (!element_cmp(keypair->K, new_kp->K)) 
	{
		printf("\n\n***** Success: retrieved encryption matches original for user: (%d)*****\n",index);
	}
	else
	{
		printf("\n\n$$$$$ Failure: Decryption Key for [User %d] does not match! $$$$$\n", index);
	}
	//element_clear(new_K);



	printf("\n\nEighth: write encryption key K to file encK.txt\n");

	//create an array of arrays to hold encryption key bytes
	unsigned char encK_Bytes[element_length_in_bytes(new_kp->K)];

	int len_encK = element_to_bytes(encK_Bytes, new_kp->K);
	printf("len_encK: %d \n", len_encK);

	//create a file k.txt and write key to it.
	FILE *kf = fopen("encK.txt", "w");
	if(fwrite(encK_Bytes, len_encK, 1, kf) != len_encK)
	{
		printf("FAILURE: (fwrite(encK_Bytes, len_encK, 1, kf) != len_encK) \n");
	}


	fclose(kf);


	//open file, and read its bytes
	unsigned char read_encK_Bytes[element_length_in_bytes(new_kp->K)];
	kf = fopen("encK.txt","r");
	if(fread(read_encK_Bytes,1,len_encK,kf) != len_encK)
	{
		printf("FAILURE: (fread(read_encK_Bytes,1,len_encK,kf) != len_encK) \n");
	}


	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	//create element test_K to hold re-constructed enc key
	element_t test_K;
	element_init_GT(test_K, gps->pairing);
	
	int len_set_key = element_from_bytes(test_K, read_encK_Bytes);
	printf("len_set_key (element_from_bytes): %d \n", len_set_key);



	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	

	element_printf("The re-constructed encryption key from file: test_K = %B\n", test_K);

	if (!element_cmp(keypair->K, test_K)) 
	{
		printf("\n\n***** Success: re-constructed k from file is same as original *****\n");
	}
	else
	{
		printf("\n\n$$$$$ Failure: re-constructed key and original key not match! $$$$$\n");
	}


	
	
	
#endif


#if reconstruct_from_files


	
	printf("\n\nIn this test, we check the following:\n");
	printf("1) The ability to read PK to file (pk.txt).\n");
	printf("2) The ability to read HDR from file (hdr.txt).\n");
	printf("3) The ability to read a private key from file (pr.txt).\n");
	printf("4) ** The ability to retrieve K using HDR and private key from respective files **\n");

	

	

	printf("\n\nFirst, read (pk.txt) and re-construct public_key.\n");


	//public_key = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	pubkey_t public_key;
	public_key = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	public_key->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	public_key->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	
	//set public_key->g using the bytes read in g_bytes
	/*Can you change this to pbc_malloc*/
	element_init_same_as(public_key->g,sys->PK->g);


	
	//open pkfile
	FILE *pkFile = fopen("pk.txt", "r");
	int res;

	//1- read and reconstruct public_key->g
	unsigned char new_g_bytes[128];
	
	res = fread(new_g_bytes,1,128,pkFile);
	//set public_key->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(public_key->g, new_g_bytes);

	//2- read and reconstruct public_key->g_i
	unsigned char new_g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//read from file
		res = fread(new_g_i_bytes[i],1,128,pkFile);

		//initialize public_key->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(public_key->g_i[i],sys->PK->g_i[i]);

		//set public_key->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(public_key->g_i[i], new_g_i_bytes[i]);
		//printf("For public_key->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	//3- read and reconstruct public_key->v_i
	unsigned char new_v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];
	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//read from file
		res = fread(new_v_i_bytes[i],1,128,pkFile);
		
		//initialize public_key->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(public_key->v_i[i],sys->PK->v_i[i]);

		//set public_key->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(public_key->v_i[i], new_v_i_bytes[i]);
		//printf("For public_key->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}


	//close pkfile
	fclose(pkFile);


	

	//----------------------------------------------------------------------------------------
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t keypair;
	get_encryption_key(&keypair, S, c, sys, gps);
	//----------------------------------------------------------------------------------------
	
	printf("\n\nSecond: read HDRfrom  hdr.txt\n");
	 
	//printf("Create and open a file \n");
	FILE *hdrfile; 

	// open file for writing 
	hdrfile = fopen ("hdr.txt", "r");  


	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	

	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		res = fread(read_HDR_bytes[i],1,128,hdrfile);
		printf("For read_HDR_bytes[%d], the number of read bytes: %d \n", i, res);
	}

	fclose(hdrfile);


	//re-construct the HDR elements
	//create new key pair: new_kp to store re-constructed HDR elements (and later to store retreived encryption key).
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));
	

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//printf("(A) step: %d \n", i);

		//initialize new_kp->HDR[i] as keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i], keypair->HDR[i]);

		//printf("(B) step: %d \n", i);

		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], read_HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}


	

	int index = 2; //choose user with index 2


	
	printf("\n\nThird: read private key from file\n");

	// open file for writing 
	FILE *privateFile = fopen ("pr.txt", "r");  

	//read private key
	unsigned char read_private[element_length_in_bytes(sys->d_i[index])];
	res = fread(read_private,1,128,privateFile);
	printf("\nFor read_private, the number of read bytes: %d \n", res);


	
	//create a new element_t to contain re-constructed private key
	element_t private_key;
	element_init_G1(private_key, gps->pairing);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(private_key/*new_struct->d_i[index]*/, read_private);
	printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: private_key = %B\n", private_key);

	

	printf("\n\nFourth: use re-constructed HDR and private key to retrieve encryption key K, c=%d\n", c);

	//new_kp->K = get decryption key	
	get_decryption_key(/*new_K*/new_kp->K, gps, S, c, index, /*reconstructed private key*/private_key, 
				/*reconstucted HDR*/new_kp->HDR, /*reconstructed pk*/public_key);
	

	
	element_printf("The retrieved encryption key: new_kp->K = %B\n", new_kp->K);
#endif

#if testing_conversion
	printf("\n\nTesting conversion of various elements to raw bytes and back to elements \n\n");
	printf("\n********** Check if private keys in sys->d_i can be copied to a new structure test_struct->d_i **********\n");
	
	/*
	for (int i = 0; i < 2; i++) 
	{
		printf("The original private key for user index = (%d), ", i);
		element_printf("d_i = %B\n", sys->d_i[i]);
	}
	*/

	/*******************************************************************************************
	This structure test_struct is used to test the ability of setting/storing private keys and PK
	********************************************************************************************/
	bkem_system_t test_struct;
	test_struct = pbc_malloc(sizeof(struct bkem_system_s));
	test_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	test_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	test_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for private keys d_i's
	test_struct->d_i = pbc_malloc(gps->N * sizeof(struct element_s));
	


	for (int i = 0; i < gps->N; ++i) 
	{
		//printf("i: %d \n", i);
		element_init_same_as(test_struct->d_i[i],sys->d_i[i]);
		element_set(test_struct->d_i[i],sys->d_i[i]);
	}

	//printf("\nExperimental (element_set) is finished \n");
	
	/*
	for (int i = 0; i < 2; i++) 
	{
		printf("The stored private key for user index = (%d), ", i);
		element_printf("d_i = %B\n", test_struct->d_i[i]);
	}
	*/

	int successful = 1;

	for(int i=0; i<gps->N; i++)
	{
		if(!element_cmp(test_struct->d_i[i], sys->d_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			printf("\n\n***** Failure: test_struct->d_i[%d] != sys->d_i[%d] *****\n", i,i);
			successful = 0;
		}
	}

	if(successful) printf("\n\n***** Success: test_struct->d_i[i] == sys->d_i[i] for all N = %d keys*****\n", gps->N);	


	/********************************************************************************************
	********************************************************************************************/


#if 0

	printf("\n********** Check if a private key test_struct->d_i[0] can be converted to bytes bytes **********\n");

	//check length
	//convert elements (private keys) to bytes
	unsigned char *d_i_0, *d_i_1;
	int len0 = element_length_in_bytes(test_struct->d_i[0]); 
	//printf("Length of e0 from length function is: %d \n", len0);
	d_i_0 = (unsigned char *) malloc(len0);
	int len01 = element_to_bytes(d_i_0, test_struct->d_i[0]);
	//printf("Length of e0 from conversion function is: %d \n", len01);

	/*
	printf("\nTesting with d_i_0 = [ ");
	for (int i = 0; i < len01; ++i) {
	    printf("%d ", d_i_0[i]);
	}
	printf("]\n\n");
	*/
	int len1 = element_length_in_bytes(test_struct->d_i[1]);
	//printf("Length of e1 from length function is: %d \n", len1);
	d_i_1 = (unsigned char *) malloc(len1);	
	int len11 = element_to_bytes(d_i_1, test_struct->d_i[1]);
	//printf("Length of e1 from conversion function is: %d \n", len11);
	/*
	printf("\nTesting with d_i_1 = [ ");
	for (int i = 0; i < len11; ++i) {
	    printf("%d ", d_i_1[i]);
	}
	printf("]\n\n");
	*/

	printf("\n********** Check if a private key new_struct->d_i[0] can be read from bytes **********\n");

	/*******************************************************************************************
	This structure new_struct is used to test the ability of restoring a private key 
	given its corresponding bytes
	********************************************************************************************/
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for this private keys d_i (just one)
	new_struct->d_i = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->d_i[0],test_struct->d_i[0]);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(new_struct->d_i[0], d_i_0);
	//printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: d_i_0 = %B\n", new_struct->d_i[0]);

	if(!element_cmp(new_struct->d_i[0], sys->d_i[0]))
	{
		printf("\n\n***** Success: new_struct->d_i[0] == sys->d_i[0] *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->d_i[0] != sys->d_i[0] *****\n");
	}

#endif

	printf("\n********** Check if a private key test_struct->d_i[0] can be converted to bytes bytes, \n");
	printf("********** written to a file pr.txt, and then re-constructed from bytes 	 **********\n");

	//check length
	//convert elements (private keys) to bytes
	unsigned char *d_i_0;
	int len0 = element_length_in_bytes(test_struct->d_i[0]); 
	//printf("Length of e0 from length function is: %d \n", len0);
	d_i_0 = (unsigned char *) malloc(len0);
	int len01 = element_to_bytes(d_i_0, test_struct->d_i[0]);
	//printf("Length of e0 from conversion function is: %d \n", len01);

	
	printf("\nTesting with d_i_0 = [ ");
	for (int i = 0; i < len01; ++i) {
	    printf("%d ", d_i_0[i]);
	}
	printf("]\n\n");
	
	printf("\n********** Write d_i[0] to file pr.txt **********\n");
	FILE *fl;
	fl = fopen("pr.txt", "w");
	fwrite(d_i_0, len01, 1, fl);
	fclose(fl);

	printf("\n********** Check if a private key new_struct->d_i[0] can be read from pr.txt and reconstructed **********\n");

	
	unsigned char *d_i_0_r;
	d_i_0_r = (unsigned char *) malloc(len01);
	fl = fopen("pr.txt", "r");
	fread(d_i_0_r, 1, len01, fl);
	fclose(fl);
	printf("\nTesting with d_i_0_r = [ ");
	for (int i = 0; i < len01; ++i) {
	    printf("%d ", d_i_0_r[i]);
	}
	printf("]\n\n");

	/*******************************************************************************************
	This structure new_struct is used to test the ability of restoring a private key 
	given its corresponding bytes
	********************************************************************************************/
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for this private keys d_i (just one)
	new_struct->d_i = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->d_i[0],test_struct->d_i[0]);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(new_struct->d_i[0], d_i_0_r);
	//printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: d_i_0 = %B\n", new_struct->d_i[0]);

	if(!element_cmp(new_struct->d_i[0], sys->d_i[0]))
	{
		printf("\n\n***** Success: new_struct->d_i[0] == sys->d_i[0] *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->d_i[0] != sys->d_i[0] *****\n");
	}




	
#if 0

	//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)

	printf("\n\n\nCheck if a PK can be transferred to bytes and then re-created from bytes ***\n");
	printf("\nFirst, check if sys->PK->g can be read in bytes and then re-created from bytes\n");


	//element_printf("The original PK->g is = %B\n", sys->PK->g);


	unsigned char *g_bytes;
	
	int len_g = element_length_in_bytes(sys->PK->g); 
	//printf("Length of g from length function is: %d \n", len_g);
	g_bytes = (unsigned char *) malloc(len_g);
	int len_g1 = element_to_bytes(g_bytes, sys->PK->g);
	//printf("Length of g from conversion function is: %d \n", len_g1);
	/*
	printf("\nRead g_bytes in bytes = [ ");
	for (int i = 0; i < len_g1; ++i) {
	    printf("%d ", g_bytes[i]);
	}
	printf("]\n\n");
	*/
	
	//set new_struct->PK->g using the bytes read in g_bytes
	//new_struct->PK->g = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->PK->g,sys->PK->g);

	
	//set new_struct->PK->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(new_struct->PK->g, g_bytes);
	//printf("len_set_g (element_from_bytes): %d \n", len_set_g);

	//element_printf("The recreated PK->g for bytes: g_bytes = %B\n", new_struct->PK->g);

	if(!element_cmp(new_struct->PK->g, sys->PK->g))
	{
		printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->PK->g != sys->PK->g *****\n");
	}

	printf("\nSecond, check if sys->PK->g_i can be read in bytes and then re-created from bytes\n");
	unsigned char g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len = 0;
	for(int i=0; i<2*gps->B;i++)
	{
		//g_i_bytes[i] = (unsigned char *) malloc(element_length_in_bytes(sys->PK->g_i[i]));
		len = element_to_bytes(g_i_bytes[i], sys->PK->g_i[i]);

		/*printf("\nRead g_i_bytes[%d] in bytes = [ ",i);
		for (int t = 0; t < len; ++t) {
		    printf("%d ", g_i_bytes[i][t]);
		}
		printf("]\n\n");*/
	}

	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//initialize new_struct->PK->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(new_struct->PK->g_i[i],sys->PK->g_i[i]);

		//set new_struct->PK->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(new_struct->PK->g_i[i], g_i_bytes[i]);
		printf("For new_struct->PK->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	successful = 1;
	for(int i=0; i<2*gps->B; i++)
	{
		if(!element_cmp(new_struct->PK->g_i[i],sys->PK->g_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->g_i[%d] != sys->PK->g_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->g_i[i] == sys->PK->g_i[i] for all 2*gps->B = %d *****\n", 2*gps->B);

	
	printf("\nThird, check if sys->PK->v_i can be read in bytes and then re-created from bytes\n");
	unsigned char v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{
		len_v = element_to_bytes(v_i_bytes[i], sys->PK->v_i[i]);
	}


	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//initialize new_struct->PK->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(new_struct->PK->v_i[i],sys->PK->v_i[i]);

		//set new_struct->PK->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(new_struct->PK->v_i[i], v_i_bytes[i]);
		printf("For new_struct->PK->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}

	successful = 1;
	for(int i=0; i<gps->A; i++)
	{
		if(!element_cmp(new_struct->PK->v_i[i],sys->PK->v_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->v_i[%d] != sys->PK->v_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->v_i[i] == sys->PK->v_i[i] for all gps->A = %d *****\n", gps->A);

	
	printf("\n\n\nCheck if HDR can be transferred to bytes and then re-created from bytes ***\n");
	//recreate a key pair for c = N (maximum), read HDR, convert HDR to bytes, recreate HDR from bytes and compare recreated HDR with original HDR.
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t new_keypair;
	get_encryption_key(&new_keypair, S, c, sys, gps);

	element_t new_K;


	for (j = 0; j < gps->N; ++j) {
	    get_decryption_key(new_K, gps, S, c, j, sys->d_i[j], new_keypair->HDR, sys->PK);
	    if (!element_cmp(new_keypair->K, new_K)) {
		if (j >= c)
		{
			printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
		}
		/*if(c == 2)
		{
			printf("With c == %d, and when user index = (%d), \n", c, j);
			element_printf("the private key  = %B\n", sys->d_i[j]);
			element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
		}*/
		          
	    } else {
		if (j < c)
		    printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
	    }
	    element_clear(new_K);
	}
	//free(new_keypair);


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	//convert new_key->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], new_keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}


	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	//create new key pair: new_kp to store re-constructed HDR elements
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i],new_keypair->HDR[i]);


		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}

	successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i],new_keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != new_keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_kp->HDR[i] == new_keypair->HDR[i] for all gps->A+1 = %d *****\n", gps->A+1);
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

	
	free(d_i_0);
	free(d_i_1);
#endif
#endif

#if testing_writing_user_files

	printf("\n\nTesting writing a user-targeted files, each containing N + user index + HDR + private key \n\n");

	printf("Create and open a file \n");
	FILE *outfile; 
      
	// open file for writing 
	outfile = fopen ("user.dat", "w"); 

	

	printf("\n\n\nCheck if HDR can be transferred to bytes and then written to user.dat***\n");
	//recreate a key pair for c = N (maximum), read HDR, convert HDR to bytes, and then write bytes to user.dat.
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t new_keypair;
	get_encryption_key(&new_keypair, S, c, sys, gps);

	element_t new_K;


	for (j = 0; j < gps->N; ++j) {
	    get_decryption_key(new_K, gps, S, c, j, sys->d_i[j], new_keypair->HDR, sys->PK);
	    if (!element_cmp(new_keypair->K, new_K)) {
		if (j >= c)
		{
			printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
		}
		/*if(c == 2)
		{
			printf("With c == %d, and when user index = (%d), \n", c, j);
			element_printf("the private key  = %B\n", sys->d_i[j]);
			element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
		}*/
		          
	    } else {
		if (j < c)
		    printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
	    }
	    element_clear(new_K);
	}
	//free(new_keypair);


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	//convert new_key->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], new_keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}

	

	//write N to file
    	fwrite(&gps->N, sizeof(int), 1, outfile);

	//write user index - 0 - to file
	int index = 2;
	fwrite(&index, sizeof(int), 1, outfile);

	//write HDR to file
	for(int i=0; i<(gps->A + 1);i++)
	{
		fwrite(HDR_bytes[i], 128, 1, outfile);
	}

	//convert corresponding private key to bytes
	unsigned char *private_bytes;
	int len_private = element_length_in_bytes(sys->d_i[index]); 
	private_bytes = (unsigned char *) malloc(len_private);
	int len01 = element_to_bytes(private_bytes,sys->d_i[index]);
	printf("Length of private key from conversion function is: %d \n", len01);
	//write private key that corresponds with user's index to file
	fwrite(private_bytes, len01, 1, outfile);

	// close file 
    	fclose (outfile);
	
	printf("\nA file is created containing N + user index (%d) + HDR + private key \n",index);

	
	FILE *infile; 
      
	// open file for writing 
	infile = fopen ("user.dat", "r");  

	int read_n;
	int res;

	res = fread(&read_n,1,sizeof(int),infile);
	printf("\n1) The number of read bytes: %d, and the read N value: %d \n", res, read_n);

	int read_index;

	res = fread(&read_index,1,sizeof(int),infile);
	printf("\n2) The number of read bytes: %d, and the read index value: %d \n", res, read_index);


	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	
	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		res = fread(read_HDR_bytes[i],1,128,infile);
		printf("3) For read_HDR_bytes[%d], the number of read bytes: %d \n", i, res);
	}

	//read private key
	unsigned char read_private[element_length_in_bytes(sys->d_i[index])];
	res = fread(read_private,1,128,infile);
	printf("\n4) For read_private, the number of read bytes: %d \n", res);


	printf("\n\nNow convert the read HDR and private key to elements and compare with original values\n\n");

	
	
	/*******************************************************************************************
	This structure new_struct is used to test the ability of restoring a private key 
	given its corresponding bytes
	********************************************************************************************/
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for this private keys d_i (just one)
	new_struct->d_i = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->d_i[index],sys->d_i[0]);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(new_struct->d_i[index], read_private);
	printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: d_i_0 = %B\n", new_struct->d_i[0]);

	if(!element_cmp(new_struct->d_i[index], sys->d_i[index]))
	{
		printf("\n\n***** Success: new_struct->d_i[%d] == sys->d_i[%d] *****\n",index,index);	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->d_i[%d] != sys->d_i[%d] *****\n",index,index);
	}




	//After reconstructing the private key and comparing it with the original key,
	//re-construct the HDR elements and compare with original HDR.
	//create new key pair: new_kp to store re-constructed HDR elements
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));
	

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//printf("(A) step: %d \n", i);

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i],new_keypair->HDR[i]);

		//printf("(B) step: %d \n", i);

		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}



	int successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i],new_keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != new_keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_kp->HDR[i] == new_keypair->HDR[i] for all gps->A+1 = %d *****\n", gps->A+1);


	fclose (infile);

	

#endif

	printf("\nMy test is finished \n\n\n");


	

}
