#include "bkem.h"


#define testing_conversion 0
#define testing_writing_user_files 1

int main(int argc, const char *argv[]) {

	FILE *param = fopen("a.param", "r");
	char buf[4096];
	fread(buf, 1, 4096, param);

	printf("\nThis is testscheme...\n");
	printf("\nSystem setup Key\n\n");

	bkem_global_params_t gps;
	setup_global_system(&gps, (const char*) buf, (argc > 1) ? atoi(argv[1]) : 256);

	printf("Global System parameters: N = %d, A = %d, B = %d\n\n", gps->N, gps->A, gps->B);

	//sys: a structure contains two elements: 1) a structure holding the public key PK. 2) an array of N private keys.
	//PK is itself a structure as shown in bkem.h 
	//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
	bkem_system_t sys; 
	setup(&sys, gps);
    
	printf("\nTesting system\n\n");

	
    
	    
	unsigned int c,k,j;
	for (c = 2; c <= gps->N; c*=2) {
		

		int S[c];
		printf("\nTesting with S = [ ");
		for (k = 0; k < c; ++k) {
		    S[k] = k;
		    printf("%d ", k);
		}
		printf("]\n\n");

		keypair_t keypair;
		get_encryption_key(&keypair, S, c, sys, gps);


		element_t K;


		for (j = 0; j < gps->N; ++j) {
		    get_decryption_key(K, gps, S, c, j, sys->d_i[j], keypair->HDR, sys->PK);
		    if (!element_cmp(keypair->K, K)) {
			if (j >= c)
			{
				printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
			}
			/*if(c == 2)
			{
				printf("With c == %d, and when user index = (%d), \n", c, j);
				element_printf("the private key  = %B\n", sys->d_i[j]);
				element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
			}*/
			          
		    } else {
			if (j < c)
			    printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
		    }
		    element_clear(K);
		}
		free(keypair);

	}



	printf("\n\n\nMy test is beginning here \n\n\n");
#if testing_conversion
	printf("\n\nTesting conversion of various elements to raw bytes and back to elements \n\n");
	printf("\n********** Check if private keys in sys->d_i can be copied to a new structure test_struct->d_i **********\n");
	
	/*
	for (int i = 0; i < 2; i++) 
	{
		printf("The original private key for user index = (%d), ", i);
		element_printf("d_i = %B\n", sys->d_i[i]);
	}
	*/

	/*******************************************************************************************
	This structure test_struct is used to test the ability of setting/storing private keys and PK
	********************************************************************************************/
	bkem_system_t test_struct;
	test_struct = pbc_malloc(sizeof(struct bkem_system_s));
	test_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	test_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	test_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for private keys d_i's
	test_struct->d_i = pbc_malloc(gps->N * sizeof(struct element_s));
	


	for (int i = 0; i < gps->N; ++i) 
	{
		//printf("i: %d \n", i);
		element_init_same_as(test_struct->d_i[i],sys->d_i[i]);
		element_set(test_struct->d_i[i],sys->d_i[i]);
	}

	//printf("\nExperimental (element_set) is finished \n");
	
	/*
	for (int i = 0; i < 2; i++) 
	{
		printf("The stored private key for user index = (%d), ", i);
		element_printf("d_i = %B\n", test_struct->d_i[i]);
	}
	*/

	int successful = 1;

	for(int i=0; i<gps->N; i++)
	{
		if(!element_cmp(test_struct->d_i[i], sys->d_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			printf("\n\n***** Failure: test_struct->d_i[%d] != sys->d_i[%d] *****\n", i,i);
			successful = 0;
		}
	}

	if(successful) printf("\n\n***** Success: test_struct->d_i[i] == sys->d_i[i] for all N = %d keys*****\n", gps->N);	


	/********************************************************************************************
	********************************************************************************************/




	printf("\n********** Check if a private key test_struct->d_i[0] can be converted to bytes bytes **********\n");

	//check length
	//convert elements (private keys) to bytes
	unsigned char *d_i_0, *d_i_1;
	int len0 = element_length_in_bytes(test_struct->d_i[0]); 
	//printf("Length of e0 from length function is: %d \n", len0);
	d_i_0 = (unsigned char *) malloc(len0);
	int len01 = element_to_bytes(d_i_0, test_struct->d_i[0]);
	//printf("Length of e0 from conversion function is: %d \n", len01);

	/*
	printf("\nTesting with d_i_0 = [ ");
	for (int i = 0; i < len01; ++i) {
	    printf("%d ", d_i_0[i]);
	}
	printf("]\n\n");
	*/
	int len1 = element_length_in_bytes(test_struct->d_i[1]);
	//printf("Length of e1 from length function is: %d \n", len1);
	d_i_1 = (unsigned char *) malloc(len1);	
	int len11 = element_to_bytes(d_i_1, test_struct->d_i[1]);
	//printf("Length of e1 from conversion function is: %d \n", len11);
	/*
	printf("\nTesting with d_i_1 = [ ");
	for (int i = 0; i < len11; ++i) {
	    printf("%d ", d_i_1[i]);
	}
	printf("]\n\n");
	*/

	printf("\n********** Check if a private key new_struct->d_i[0] can be read from bytes **********\n");

	/*******************************************************************************************
	This structure new_struct is used to test the ability of restoring a private key 
	given its corresponding bytes
	********************************************************************************************/
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for this private keys d_i (just one)
	new_struct->d_i = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->d_i[0],test_struct->d_i[0]);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(new_struct->d_i[0], d_i_0);
	//printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: d_i_0 = %B\n", new_struct->d_i[0]);

	if(!element_cmp(new_struct->d_i[0], sys->d_i[0]))
	{
		printf("\n\n***** Success: new_struct->d_i[0] == sys->d_i[0] *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->d_i[0] != sys->d_i[0] *****\n");
	}


	


	//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)

	printf("\n\n\nCheck if a PK can be transferred to bytes and then re-created from bytes ***\n");
	printf("\nFirst, check if sys->PK->g can be read in bytes and then re-created from bytes\n");


	//element_printf("The original PK->g is = %B\n", sys->PK->g);


	unsigned char *g_bytes;
	
	int len_g = element_length_in_bytes(sys->PK->g); 
	//printf("Length of g from length function is: %d \n", len_g);
	g_bytes = (unsigned char *) malloc(len_g);
	int len_g1 = element_to_bytes(g_bytes, sys->PK->g);
	//printf("Length of g from conversion function is: %d \n", len_g1);
	/*
	printf("\nRead g_bytes in bytes = [ ");
	for (int i = 0; i < len_g1; ++i) {
	    printf("%d ", g_bytes[i]);
	}
	printf("]\n\n");
	*/
	
	//set new_struct->PK->g using the bytes read in g_bytes
	//new_struct->PK->g = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->PK->g,sys->PK->g);

	
	//set new_struct->PK->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(new_struct->PK->g, g_bytes);
	//printf("len_set_g (element_from_bytes): %d \n", len_set_g);

	//element_printf("The recreated PK->g for bytes: g_bytes = %B\n", new_struct->PK->g);

	if(!element_cmp(new_struct->PK->g, sys->PK->g))
	{
		printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->PK->g != sys->PK->g *****\n");
	}

	printf("\nSecond, check if sys->PK->g_i can be read in bytes and then re-created from bytes\n");
	unsigned char g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len = 0;
	for(int i=0; i<2*gps->B;i++)
	{
		//g_i_bytes[i] = (unsigned char *) malloc(element_length_in_bytes(sys->PK->g_i[i]));
		len = element_to_bytes(g_i_bytes[i], sys->PK->g_i[i]);

		/*printf("\nRead g_i_bytes[%d] in bytes = [ ",i);
		for (int t = 0; t < len; ++t) {
		    printf("%d ", g_i_bytes[i][t]);
		}
		printf("]\n\n");*/
	}

	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//initialize new_struct->PK->g_i[i] as sys->PK->g_i[i]
		element_init_same_as(new_struct->PK->g_i[i],sys->PK->g_i[i]);

		//set new_struct->PK->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(new_struct->PK->g_i[i], g_i_bytes[i]);
		printf("For new_struct->PK->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	successful = 1;
	for(int i=0; i<2*gps->B; i++)
	{
		if(!element_cmp(new_struct->PK->g_i[i],sys->PK->g_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->g_i[%d] != sys->PK->g_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->g_i[i] == sys->PK->g_i[i] for all 2*gps->B = %d *****\n", 2*gps->B);

	
	printf("\nThird, check if sys->PK->v_i can be read in bytes and then re-created from bytes\n");
	unsigned char v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{
		len_v = element_to_bytes(v_i_bytes[i], sys->PK->v_i[i]);
	}


	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//initialize new_struct->PK->v_i[i] as sys->PK->v_i[i]
		element_init_same_as(new_struct->PK->v_i[i],sys->PK->v_i[i]);

		//set new_struct->PK->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(new_struct->PK->v_i[i], v_i_bytes[i]);
		printf("For new_struct->PK->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}

	successful = 1;
	for(int i=0; i<gps->A; i++)
	{
		if(!element_cmp(new_struct->PK->v_i[i],sys->PK->v_i[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_struct->PK->v_i[%d] != sys->PK->v_i[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_struct->PK->v_i[i] == sys->PK->v_i[i] for all gps->A = %d *****\n", gps->A);

	
	printf("\n\n\nCheck if HDR can be transferred to bytes and then re-created from bytes ***\n");
	//recreate a key pair for c = N (maximum), read HDR, convert HDR to bytes, recreate HDR from bytes and compare recreated HDR with original HDR.
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t new_keypair;
	get_encryption_key(&new_keypair, S, c, sys, gps);

	element_t new_K;


	for (j = 0; j < gps->N; ++j) {
	    get_decryption_key(new_K, gps, S, c, j, sys->d_i[j], new_keypair->HDR, sys->PK);
	    if (!element_cmp(new_keypair->K, new_K)) {
		if (j >= c)
		{
			printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
		}
		/*if(c == 2)
		{
			printf("With c == %d, and when user index = (%d), \n", c, j);
			element_printf("the private key  = %B\n", sys->d_i[j]);
			element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
		}*/
		          
	    } else {
		if (j < c)
		    printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
	    }
	    element_clear(new_K);
	}
	//free(new_keypair);


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	//convert new_key->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], new_keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}


	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
	//create new key pair: new_kp to stored re-constructed HDR elements
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i],new_keypair->HDR[i]);


		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}

	successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i],new_keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != new_keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_kp->HDR[i] == new_keypair->HDR[i] for all gps->A+1 = %d *****\n", gps->A+1);
	//$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

	
	free(d_i_0);
	free(d_i_1);
#endif

#if testing_writing_user_files

	printf("\n\nTesting writing a user-targeted files, each containing N + user index + HDR + private key \n\n");

	printf("Create and open a file \n");
	FILE *outfile; 
      
	// open file for writing 
	outfile = fopen ("user.dat", "w"); 

	

	printf("\n\n\nCheck if HDR can be transferred to bytes and then written to user.dat***\n");
	//recreate a key pair for c = N (maximum), read HDR, convert HDR to bytes, and then write bytes to user.dat.
	c = gps->N;	
	int S[c];
	printf("\nTesting with S = [ ");
	for (k = 0; k < c; ++k) {
	    S[k] = k;
	    printf("%d ", k);
	}
	printf("]\n\n");

	keypair_t new_keypair;
	get_encryption_key(&new_keypair, S, c, sys, gps);

	element_t new_K;


	for (j = 0; j < gps->N; ++j) {
	    get_decryption_key(new_K, gps, S, c, j, sys->d_i[j], new_keypair->HDR, sys->PK);
	    if (!element_cmp(new_keypair->K, new_K)) {
		if (j >= c)
		{
			printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
		}
		/*if(c == 2)
		{
			printf("With c == %d, and when user index = (%d), \n", c, j);
			element_printf("the private key  = %B\n", sys->d_i[j]);
			element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
		}*/
		          
	    } else {
		if (j < c)
		    printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
	    }
	    element_clear(new_K);
	}
	//free(new_keypair);


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	//convert new_key->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], new_keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}

	

	//write N to file
    	fwrite(&gps->N, sizeof(int), 1, outfile);

	//write user index - 0 - to file
	int index = 2;
	fwrite(&index, sizeof(int), 1, outfile);

	//write HDR to file
	for(int i=0; i<(gps->A + 1);i++)
	{
		fwrite(HDR_bytes[i], 128, 1, outfile);
	}

	//convert corresponding private key to bytes
	unsigned char *private_bytes;
	int len_private = element_length_in_bytes(sys->d_i[index]); 
	private_bytes = (unsigned char *) malloc(len_private);
	int len01 = element_to_bytes(private_bytes,sys->d_i[index]);
	printf("Length of private key from conversion function is: %d \n", len01);
	//write private key that corresponds with user's index to file
	fwrite(private_bytes, len01, 1, outfile);

	// close file 
    	fclose (outfile);
	
	printf("\nA file is created containing N + user index (%d) + HDR + private key \n",index);

	
	FILE *infile; 
      
	// open file for writing 
	infile = fopen ("user.dat", "r");  

	int read_n;
	int res;

	res = fread(&read_n,1,sizeof(int),infile);
	printf("\n1) The number of read bytes: %d, and the read N value: %d \n", res, read_n);

	int read_index;

	res = fread(&read_index,1,sizeof(int),infile);
	printf("\n2) The number of read bytes: %d, and the read index value: %d \n", res, read_index);


	//create an array of arrays to hold HDR's read bytes
	unsigned char read_HDR_bytes[(gps->A + 1)][element_length_in_bytes(new_keypair->HDR[0])];

	
	//read HDR elements iteratively
	for(int i=0; i<(gps->A + 1);i++)
	{
		res = fread(read_HDR_bytes[i],1,128,infile);
		printf("3) For read_HDR_bytes[%d], the number of read bytes: %d \n", i, res);
	}

	//read private key
	unsigned char read_private[element_length_in_bytes(sys->d_i[index])];
	res = fread(read_private,1,128,infile);
	printf("\n4) For read_private, the number of read bytes: %d \n", res);


	printf("\n\nNow convert the read HDR and private key to elements and compare with original values\n\n");

	
	
	/*******************************************************************************************
	This structure new_struct is used to test the ability of restoring a private key 
	given its corresponding bytes
	********************************************************************************************/
	bkem_system_t new_struct;
	new_struct = pbc_malloc(sizeof(struct bkem_system_s));
	new_struct->PK = pbc_malloc(sizeof(struct pubkey_s));
	// allocate memory for g_i's
	new_struct->PK->g_i = pbc_malloc(2 * gps->B * sizeof(element_t));
	// allocate memory for v_i's
	new_struct->PK->v_i = pbc_malloc(gps->A * sizeof(struct element_s));
	// allocate memory for this private keys d_i (just one)
	new_struct->d_i = pbc_malloc(1 * sizeof(struct element_s));
	element_init_same_as(new_struct->d_i[index],sys->d_i[0]);

	
	//set element (private key) from the given bytes
	int len_set_bytes = element_from_bytes(new_struct->d_i[index], read_private);
	printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);

	//element_printf("The recreated private key for bytes: d_i_0 = %B\n", new_struct->d_i[0]);

	if(!element_cmp(new_struct->d_i[index], sys->d_i[index]))
	{
		printf("\n\n***** Success: new_struct->d_i[%d] == sys->d_i[%d] *****\n",index,index);	
	}
	else
	{
		printf("\n\n***** Failure: new_struct->d_i[%d] != sys->d_i[%d] *****\n",index,index);
	}




	//After reconstructing the private key and comparing it with the original key,
	//re-construct the HDR elements and compare with original HDR.
	//create new key pair: new_kp to stored re-constructed HDR elements
	keypair_t new_kp;
    	new_kp = pbc_malloc(sizeof(struct keypair_s));
    	new_kp->HDR = pbc_malloc((gps->A + 1) * sizeof(element_t));

	int len_set_hdr_i;
	for(int i=0; i<(gps->A + 1); i++)
	{

		//initialize new_kp->HDR[i] as new_keypair->HDR[i]
		element_init_same_as(new_kp->HDR[i],new_keypair->HDR[i]);


		//set new_kp->HDR[i] from the given bytes in HDR_bytes[i]
		len_set_hdr_i = element_from_bytes(new_kp->HDR[i], HDR_bytes[i]);
		printf("For new_kp->HDR[%d], len_set_hdr_i (element_from_bytes): %d \n", i, len_set_hdr_i);
	}

	int successful = 1;
	for(int i=0; i<(gps->A + 1); i++)
	{
		if(!element_cmp(new_kp->HDR[i],new_keypair->HDR[i]))
		{
			//printf("\n\n***** Success: new_struct->PK->g == sys->PK->g *****\n");	
		}
		else
		{
			successful = 0;
			printf("\n\n***** Failure: new_kp->HDR[%d] != new_keypair->HDR[%d] *****\n",i,i);
		}
	}

	if(successful) printf("\n\n***** Success: new_kp->HDR[i] == new_keypair->HDR[i] for all gps->A+1 = %d *****\n", gps->A+1);

	

#endif

	printf("\nMy test is finished \n\n\n");


	

}
