#include "bkem.h"


#define check_if_ok 0
#define test_reconstruct 0
#define print_function 1



bkem_global_params_t gps;	
//sys: a structure contains two elements: 1) a structure holding the public key PK. 2) an array of N private keys.
//PK is itself a structure as shown in bkem.h 
//PK = (g,g_1,...,g_B,g_(B+2),...,g_(2B),v_1,...,v_A)
bkem_system_t sys; 

char public_file_name[12] = "keys/PK.txt";
char private_file_name[16] = "keys/di-";
char subscribers_file_name[100] = "/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/subscribers.txt";
char HDR_file[14] = "keys/HDR.txt";
char encK_file[16] = "keys/encK.txt";


int in_set(int *Set, int length, int value)
{

	int found = 0;
	for(int i=0; i<length; i++)
	{
		if(Set[i] == value)
		{
			found = 1;
			break;
		}
	}
	return found;
}




void print_elements()
{

	printf("PK: \n");
	element_printf("sys->PK->g = %B\n", sys->PK->g);
	for(int i=0; i<2*gps->B;i++)
	{
		printf("sys->PK->g_i[%d] = ", i);
		element_printf(" %B\n", sys->PK->g_i[i]);
	}

	unsigned char v_i_bytes[element_length_in_bytes(sys->PK->v_i[0])];

	int len_v = 0;
	for(int i=0; i<gps->A;i++)
	{

		len_v = element_to_bytes(v_i_bytes, sys->PK->v_i[i]);

		printf("sys->PK->v_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", v_i_bytes[j]);
		printf("\n");

		//element_printf(" %B\n", i, sys->PK->v_i[i]);
	}
	

	printf("----------------------------------------------------------------\n\n");

	unsigned char d_i_bytes[element_length_in_bytes(sys->d_i[0])];

	printf("Private keys: \n");
	
	int len_d = 0;
	for(int i=0; i<gps->N; i++)
	{	
		len_d = element_to_bytes(d_i_bytes, sys->d_i[i]);

		printf(" sys->d_i[%d] = ", i);
		for(int j=0; j<len_v; j++) printf("%02x ", d_i_bytes[j]);
		printf("\n");
		//element_printf("%B\n", i, sys->d_i[i]);
	} 
	printf("----------------------------------------------------------------\n\n");
		
	
}


int restore_public_and_private()
{



	printf("\n\n\nread (keys/PK.txt) and re-construct public key.\n");
	
	
	FILE *pkFile;
	int res;

	//open pkfile
	pkFile = fopen(public_file_name, "r");

	if(pkFile == NULL)
	{
		printf("FAILED TO OPEN PUBLIC KEY FILE.\n");
		return 1;
	}
	

	//1- read and reconstruct sys->PK->g
	unsigned char new_g_bytes[128];
	
	res = fread(new_g_bytes,1,128,pkFile);
	//set sys->PK->g from the given bytes in g_bytes
	int len_set_g = element_from_bytes(sys->PK->g, new_g_bytes);

	//2- read and reconstruct sys->PK->g_i
	unsigned char new_g_i_bytes[2*gps->B][element_length_in_bytes(sys->PK->g_i[0])];
	int len_set_g_i;
	for(int i=0; i<2*gps->B; i++)
	{
		//read from file
		res = fread(new_g_i_bytes[i],1,128,pkFile);

		//set sys->PK->g_i[i] from the given bytes in g_i_bytes[i]
		len_set_g_i = element_from_bytes(sys->PK->g_i[i], new_g_i_bytes[i]);
		//printf("For sys->PK->g_i[%d], len_set_g_i (element_from_bytes): %d \n", i, len_set_g_i);
	}

	//3- read and reconstruct sys->PK->v_i
	unsigned char new_v_i_bytes[gps->A][element_length_in_bytes(sys->PK->v_i[0])];
	int len_set_v_i;
	for(int i=0; i<gps->A; i++)
	{
		//read from file
		res = fread(new_v_i_bytes[i],1,128,pkFile);

		//set sys->PK->v_i[i] from the given bytes in v_i_bytes[i]
		len_set_v_i = element_from_bytes(sys->PK->v_i[i], new_v_i_bytes[i]);
		//printf("For sys->PK->v_i[%d], len_set_v_i (element_from_bytes): %d \n", i, len_set_v_i);
	}

	

	printf("\n\n\nSecond: read and reconstruct private keys from files.\n");


	
	FILE *privateFile;
	

	unsigned char read_private[element_length_in_bytes(sys->d_i[0])];
	int len_set_bytes;


	for(int i=0; i<gps->N; i++)
	{
		
		//change file name 
		private_file_name[8] = '0' + (i/10);
		private_file_name[9] = '0' + (i%10);
		private_file_name[10] = '.';
		private_file_name[11] = 't';
		private_file_name[12] = 'x';
		private_file_name[13] = 't';
		// open file for rading 
		privateFile = fopen (private_file_name, "r");

		if(privateFile == NULL)
		{
			printf("FAILED TO OPEN PRIVATE KEY FILE, FOR USER: %d.\n", i);
			return 1;
		}



		//read private key
		res = fread(read_private,1,128,privateFile);
		printf("\nFor read_private, the number of read bytes: %d \n", res);

		
		//set element (private key) from the given bytes
		len_set_bytes = element_from_bytes(sys->d_i[i], read_private);
		printf("len_set_bytes (element_from_bytes): %d \n", len_set_bytes);
	} 


	return 0;

}


void generate_and_store_new_HDR(char *list, int num_of_subscribers)
{

	printf("This is generate_and_store_new_HDR\n");
	
	int c = num_of_subscribers;
	int S[c];
	
	for(int i=0; i<c; i++) S[i] = list[i];

	printf("\nc = %d, and S = [ ", c);
	for (int i=0; i<c; i++) printf("%d ", S[i]);
	printf("]\n\n");

	keypair_t keypair;
	get_encryption_key(&keypair, S, c, sys, gps);

	element_t new_K;


	//create an array of arrays to hold HDR's elements' bytes
	unsigned char HDR_bytes[(gps->A + 1)][element_length_in_bytes(keypair->HDR[0])];

	//convert keypair->HDR[..] to bytes and store them in HDR_Bytes[..][..]
	int len_hdr = 0;
	for(int i=0; i<(gps->A + 1);i++)
	{
		len_hdr = element_to_bytes(HDR_bytes[i], keypair->HDR[i]);
		printf("For HDR_bytes[%d], len_hdr (element_to_bytes): %d \n", i, len_hdr);
	}

	
	//printf("Create and open a file \n");
	FILE *hdrfile; 
      
	// open file for writing 
	hdrfile = fopen (HDR_file, "w"); 

	//write HDR to file
	for(int i=0; i<(gps->A + 1);i++)
	{
		fwrite(HDR_bytes[i], 128, 1, hdrfile);
	}

	fclose(hdrfile);

	printf("HDR has been written to file %s\n", HDR_file);



	//create an array of arrays to hold encryption key bytes
	unsigned char encK_Bytes[element_length_in_bytes(keypair->K)];

	int len_encK = element_to_bytes(encK_Bytes, keypair->K);
	printf("len_encK: %d \n", len_encK);

	//create a file k.txt and write key to it.
	FILE *kf = fopen(encK_file, "w");
	if(fwrite(encK_Bytes, 1, len_encK, kf) != len_encK)
	{
		printf("FAILURE: (fwrite(encK_Bytes, len_encK, 1, kf) != len_encK) \n");
	}

	fclose(kf);

	printf("Enc Key has been written to file %s\n", encK_file);



}

/*
This function adds the index if add_remove = 1, and removes the index otherwise.
If successful, the function returns 0, and 1 otherwise.
*/
int update_subscribers_list(int add_remove, int index) {

	FILE *subscribers_file; 


	//check sanity of index
	if((index < 0) || (index > (gps->N-1)))
	{
		printf("This index is not valid, can not update the list.\n");
		return 1;
	}
      
	// open file for writing 
	subscribers_file = fopen (subscribers_file_name, "r"); 

	if(subscribers_file == NULL)
	{
		printf("subscribers list file: (%s) does not exist. \n", subscribers_file_name);
		return 1;
	}

	char list_content[gps->N];

	int actual_length = fread(list_content,1,(gps->N + 1),subscribers_file);
	fclose(subscribers_file);

	printf("Subscriber's list actual_length: %d \n", actual_length);

	

	//int number_of_subscribers = list_content[0];

	//printf("Subscriber's list number_of_subscribers: %d \n", number_of_subscribers);

	//check the sanity of this list (all indices should be between 0 and N-1 inclusive)
	for(int i=0; i<actual_length; i++)
	{
		if((list_content[i] < 0) || (list_content[i] > (gps->N-1)))
		{
			printf("This list is corrupted, you need to reset the system.\n");
			return 1;
		}
	}


	if(add_remove) //add
	{
		if(actual_length == gps->N)
		{
			printf("Can not add another subscriber as number_of_subscribers == gps->N \n");
			return 1;
		}

		int already_exist = 0;
		for(int i=0; i<actual_length; i++)
		{
			if(list_content[i] == index)
			{
				printf("This user is already a subscriber. \n");
				//return 1;   //don't return for testing.
			}
		}

		if(actual_length == 0)
		{
			printf("This is the first subscriber. \n");
			list_content[actual_length] = index;
			actual_length++;
		}
		else
		{
			int placed = 0;
			for(int i=0; i<actual_length; i++)
			{
				if(list_content[i] > index) //if so, then shift all after i
				{
					for(int j=actual_length; j>i; j--)
					{
						list_content[j] = list_content[j-1];
					}
					list_content[i] = index;
					actual_length++;
					placed = 1;
				}
				
				if(placed) break;
			}
		}

		printf("User index: %d has been successfully added to list. \n", index);
		subscribers_file = fopen (subscribers_file_name, "w"); 
		fwrite(list_content, 1, actual_length, subscribers_file);
		fclose(subscribers_file);

		//generate and store new HDR and enck.txt
		generate_and_store_new_HDR(list_content, actual_length);

		return 0;
	}
	else
	{

		if(actual_length == 0)
		{
			printf("No subscribers in the list - can not remove any. \n");
			return 1;
		}
	
		int found = 0;
		for(int i=0; i<actual_length; i++)
		{
			if(list_content[i] == index)
			{
				found = 1;

				//remove this index by overwritting it with subsequent indices.
				for(int j=i; j<actual_length-1; j++)
				{
					list_content[j] = list_content[j+1];
				}

				actual_length--;
			}

			if(found) break;
		}

		if(found)
		{

			printf("User index: %d has been successfully removed from list. \n", index);
			subscribers_file = fopen (subscribers_file_name, "w"); 
			fwrite(list_content, 1, actual_length, subscribers_file);
			fclose(subscribers_file);

			//generate and store new HDR and enck.txt
			generate_and_store_new_HDR(list_content, actual_length);

			return 0;
		}
		else
		{
			printf("User index: %d does not exist in list. \n", index);
			return 1;
		}

		
	}

	return 0;
	
	
}

int main(int argc, const char *argv[]) {

	FILE *param = fopen("a.param", "r");
	char buf[4096];
	fread(buf, 1, 4096, param);

	printf("\nThis is update_subscribers...\n");



	//check if enough number of argumets passed as input
	if(argc < 5)	
	{
		printf("NOT ENOUGH ARGUMENTS IN INPUT.\n");
		return 1;
	}

	printf("Input arguments: argv[1]: %d, argv[2]: %d, argv[3]: %d, and argv[4]: %d \n", atoi(argv[1]), atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));

	
	setup_global_system(&gps, (const char*) buf, atoi(argv[1]));

	printf("Global System parameters: N = %d, A = %d, B = %d\n\n", gps->N, gps->A, gps->B);

	
	

	//This will create a sys object containing new PK and private keys,
	//however, later, this sys object will be used to store the read PK and private keys.
	setup(&sys, gps);

	if(!restore_public_and_private())
	{
		printf("Public key and all private keys are successfully restored.\n");
		printf("Continue to update the subscribers list and generate a new HDR.\n");

#if print_function
		print_elements();
#endif


		int add_remove = atoi(argv[2]);
		int index = atoi(argv[4]);
		update_subscribers_list(add_remove, index);

		return 0;
	}
	else
	{

		printf("Failure in restoring public and private keys.\n");
		return 1;
	}
    
#if check_if_ok
    
	unsigned int c,k,j;
	/*
	Test subset S with continuous indices, i.e. S = {0,1} or S = {0,1,2,3} , etc
	*/   
	int continuous_test = 1; 	
	for (c = 2; c <= gps->N; c*=2) {
		

		int S[c];
		printf("\nTesting with S = [ ");
		for (k = 0; k < c; ++k) {
		    S[k] = k;
		    printf("%d ", k);
		}
		printf("]\n\n");

		keypair_t keypair;
		get_encryption_key(&keypair, S, c, sys, gps);


		element_t K;


		for (j = 0; j < gps->N; ++j) {
		    get_decryption_key(K, gps, S, c, j, sys->d_i[j], keypair->HDR, sys->PK);
		    if (!element_cmp(keypair->K, K)) {
			if (j >= c)
			{
				printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
				continuous_test = 0;
			}
			/*if(c == 2)
			{
				printf("With c == %d, and when user index = (%d), \n", c, j);
				element_printf("the private key  = %B\n", sys->d_i[j]);
				element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
			}*/
			          
		    } else {
			if (j < c)
			{
			    	printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
				continuous_test = 0;
			}
		    }
		    element_clear(K);
		}
		free(keypair);

	}

	if(continuous_test)
	{
		printf("First test: S with continuous indices PASSED successfully\n");
	}
	else
	{
		printf("First test: S with continuous indices FAILED miserably\n");
	}


	/*
	Test subset S with non-continuous indices, i.e. S = {0,3} or S = {0,1,5} , etc
	*/ 
	int non_continuous_test = 1;
	time_t t;
	int r;
	/* Intializes random number generator */
   	srand((unsigned) time(&t));
	for (c = 1; c <= gps->N; c++) {
		

		int S[c];
		int actual_length = 0;
		//int not_empty = 0;
		for (k = 0; k < c; ++k)
		{
			r = rand()%10;
			//printf("for k: %d, r: %d \n", k, r);
			if(r > 5)
			{
				S[actual_length] = k;
				actual_length++;
			}
		    
			
		}
		
		//printf("for c: %d, actual_length: %d \n", c, actual_length);

		if(actual_length)
		{

			printf("\nTesting with S = [ ");
			for (k = 0; k < actual_length; ++k)
			{
				printf("%d ", S[k]);
			}
			printf("]\n\n");

			keypair_t keypair;
			get_encryption_key(&keypair, S, actual_length, sys, gps);


			element_t K;


			for (j = 0; j < gps->N; ++j) {
			    get_decryption_key(K, gps, S, actual_length, j, sys->d_i[j], keypair->HDR, sys->PK);	
			    if (!element_cmp(keypair->K, K)) {
				printf("Non-continuous test, decryption Key for [User %d] matches\n", j); 
				if (!in_set(S,actual_length,j))
				{
					printf("ERROR: Decryption Key for [User %d] matches, but should NOT\n", j); 
					non_continuous_test = 0;
				}
				/*if(c == 2)
				{
					printf("With c == %d, and when user index = (%d), \n", c, j);
					element_printf("the private key  = %B\n", sys->d_i[j]);
					element_printf("the retrieved symmetric (encryption) key  = %B\n", K);
				}*/
					  
			    } else {
				if (in_set(S,actual_length,j))
				{
				    	printf("ERROR: Decryption Key for [User %d] does not match!\n", j);
					non_continuous_test = 0;
				}
			    }
			    element_clear(K);
			}
			free(keypair);
		}

	}

	if(non_continuous_test)
	{
		printf("Second test: S with non-continuous indices PASSED successfully\n");
	}
	else
	{
		printf("Second test: S with non-continuous indices FAILED miserably\n");
	}

#endif 


}


