/*
This program reads the HDR file, hashes it, and add the LSB 16 bytes to the newely created
new file. If the he LSB 16 bytes of the hash value is ABCD, then the new file contains the 
following:
new file = ABCD || HDR
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "keccak.h"
#include "read_hex_file.h"


#define get_from_argv 1
#define get_from_terminal 0

const int total_num_of_users = 64;


char keyFile[16] = "keys/encK.txt";
char hdrFile[16] = "keys/HDR.txt";
char subscribers_file_name[100] = "/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/keys/subscribers.txt";
char output_subscribers_list[24] = "keys/subscribers.txt";
char output_authentication_msg[24] = "keys/auth_msg.txt";
char h_hdrFile[18] = "H_HDR.txt";
//----
char new_hdrFile[18] = "n_HDR.txt";
char part_hash_file[16] = "hash.txt";
//----
unsigned char hash[HASH_SIZE];
uint8_t buffer[4000];
union hash_state state;
//----
int release;


enum operation_modes{mode_generate=0, mode_partition=1, mode_check=2, mode_hash_key=3, mode_check_hash_key=4, mode_index_and_hash=5, mode_authenticate_hdr=6};
enum operation_modes current_mode;

//this function is copied from the Bytecoin project
void hash_process(union hash_state *state, const uint8_t *buf, size_t count) {
	keccak1600(buf, (int)count, (uint8_t*)state);
}


/*********************************************
This function does the following:
1- HK = Hash(SK), hash private key SK.
2- R = randomly generated 32 bytes.
3- H = Hash(R^HK), 
4- write LSB two bytes of H into a file
**********************************************/
int hash_private_key(char *private_file, char *hash_file)
{
	
	if(!release) printf("\nThis is hash_private_key() and private_file: %s and hash_file: %s \n", private_file, hash_file);

	
	int counter = 0;

	

	FILE *fp = fopen(private_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", private_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	if(!release) printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(private_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", keyFile);
		return 0;
	}
	
	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given private key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	
	//generated random data (32 bytes).
	unsigned char random_data[HASH_SIZE];
	time_t t;
	srand((unsigned) time(&t)); //initialize srand

	for(int i=0; i<HASH_SIZE; i++) random_data[i] = ((unsigned char)(rand() % 256)) & 0xff;
	
	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("generated random data: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", random_data[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//Xor random data with hash of private key.
	for(int i=0; i<HASH_SIZE; i++) buffer[i] = random_data[i]^hash[i];

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("random_data XOR hash(SK): \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//hash(random_data^hash(SK))
	hash_process(&state, buffer, HASH_SIZE);
	memcpy(hash, &state, HASH_SIZE);


	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash(random_data^hash(SK)): \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3- open hash file
	fp = fopen(hash_file, "w");

	//4- write LSB 2 byets of hash(random_data^hash(SK)).(bytes 0 and 1)
	counter = fwrite(hash, 1, 2, fp);
	if(!release) printf("counter for  fwrite(hash, 1, 2, fp) = (%d) \n", counter);
	if(counter != 2)
	{
		printf("\nFAILURE: writing hash to (key_hash.txt).\n");
		fclose(fp);
		return 0;
	}

	//write random_data to file
	counter = fwrite(random_data, 1, HASH_SIZE, fp);
	if(!release) printf("counter for  fwrite(hash, 1, HASH_SIZE, fp) = (%d) \n", counter);
	if(counter != HASH_SIZE)
	{
		printf("\nFAILURE: writing random_data to (key_hash.txt).\n");
		fclose(fp);
		return 0;
	}

	fclose(fp);

	return 1;
}


//This function does the following:
//1- hashes the private key found in private_file
//2- compares the LSB 2 bytes with the values in hash_file.
//3- returns 1 if both are equal, and 0 otherwise.
int check_hash_private_key(char *private_file, char *hash_file)
{
	
	if(!release) printf("\nThis is check_hash_private_key(), private_file: %s and hash_file: %s \n", private_file, hash_file);

	
	int counter = 0;

	
	//1- open and read the private key file
	FILE *fp = fopen(private_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", private_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(private_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", private_file);
		return 0;
	}
	
	//2- hash the read private key.	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given private key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3- read the given reference hash file
	fp = fopen(hash_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", hash_file);
		return 0;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int reference_hash_size = ftell(fp);

	printf("\n\nreference_hash_size: (%d) \n", reference_hash_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(hash_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, reference_hash_size, fp);
	
	
	fclose(fp);

	if(counter != reference_hash_size)
	{
		printf("Failed to read \"%s\"\n", hash_file);
		return 0;
	}


	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("Reference hash: \n");
		for(int i=0; i<2; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//4- compare the LSB 2 bytes of hash[] with the read values from the reference hash file in buffer
	for(int i=0; i<2; i++)
	{
		if(hash[i] != buffer[i])
		{
			printf("Reference hash is not the same as the hash of the given key\n");
			return 0;
		}
	}

	

	return 1;
}


/*
This function returns the index of the subscriber if successful, and returns 99 otherwise
NOTE, THIS FUNCTION WONT WORK IF THE SYSTEM HAS 99 SUBCRIBERS OR MORE.
*/
int get_index_and_hash(char *request_file, char *hash_file)
{

	printf("\nThis is get_index_and_hash(), request_file: %s and hash_file: %s \n", request_file, hash_file);

	
	int counter = 0;

	
	//1- open and read the request_file
	FILE *fp = fopen(request_file, "r");

	if(fp == NULL)
	{

		printf("This file: (%s) does not exist.\n", request_file);
		return 99;
	}

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 99;
	}

	int file_size = ftell(fp);

	printf("\n\nSubscription file size: (%d) \n", file_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(request_file, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, file_size, fp);
	
	
	fclose(fp);

	if(counter != file_size)
	{
		printf("Failed to read \"%s\"\n", request_file);
		return 0;
	}
	
	
	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("The given subscription file data: \n");
		for(int i=0; i<file_size; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3- read user index
	int user_index = buffer[0];
	if(!release) printf("Subscriber user_index: %d\n", user_index);
	

	//4- open and write buffer[1][2] to hash_file
	//open file for reading
	fp = fopen(hash_file, "w");

	//write buffer[1][2] to hash_file
	counter = fwrite(&buffer[1], 1, 2, fp);
	printf("counter for  fwrite(hash, 1, 2, fp) = (%d) \n", counter);
	if(counter != 2)
	{
		printf("\nFAILURE: writing buffer[1][2] to hash_file\n");
		fclose(fp);
		return 99;
	}

	fclose(fp);

	

	return user_index;
}



//This function reads private key and HDR, and hashes them,
//and compare hash[0] with the corresponding value in auth_msg file
int authenticate_hdr(char *user_index, char *private_key_file)
{

	if(!release) printf("This is authenticate_hdr() \n");
	if(!release) printf("User index (string): %s, and private key file: %s \n", user_index, private_key_file);

	//convert index from string to int
	int index = ((user_index[0] - 48) * 10) + (user_index[1] - 48);

	if(!release) printf("User index (integer): %d\n", index);

	//1- open HDR
	FILE *fp = fopen(hdrFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END)) 
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}


	int hdr_size = ftell(fp);

	if(!release) printf("\n\nHDR file size: (%d) \n", hdr_size);

	fclose(fp);

	//open file for reading
	fp = fopen(hdrFile, "r");
	//2- Read HDR into buffer
	int counter = fread(buffer, 1, hdr_size, fp);

	fclose(fp);

	//1- open and read private key file
	fp = fopen(private_key_file, "r");
	//2- Read HDR into buffer
	counter = fread(&buffer[hdr_size], 1, 128, fp);

	fclose(fp);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hdr+key: \n");
		for(int i=0; i<(hdr_size+128); i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	hash_process(&state, buffer, hdr_size+128);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash hdr+key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}


	//open and read auth_msg
	//open file for reading
	fp = fopen(output_authentication_msg, "r");
	//2- Read auth_msg into buffer
	counter = fread(buffer, 1, 64, fp);
	fclose(fp);

	//check if auth_msg[index] == hash[0]
	if(!release) printf("buffer[index] == %02x \n", buffer[index]);
	if(!release) printf("hash[0] == %02x \n", hash[0]);
	if(buffer[index] == hash[0])
	{
		if(!release) printf("\n$$$$$$$ HDR is successfully authenticated $$$$$$$ \n");
		return 1;
	}
	else
	{
		printf("\n~~~~~~~ Failure in authenticating HDR ~~~~~~~ \n");
		return 0;
	}		
}



//This function reads the encryption key from encK.txt, and hashes it using hash_process()
int hash_key()
{
	
	
	int counter = 0;

	

	FILE *fp = fopen(keyFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END))
	{
		printf("# fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int key_size = ftell(fp);

	if(!release) printf("\n\nKey file size: (%d) \n", key_size);

	fclose(fp);
	



	//open file for reading
	fp = fopen(keyFile, "r");

	


	/* Read and display data */
	counter = fread(buffer, 1, key_size, fp);
	
	
	fclose(fp);

	if(counter != key_size)
	{
		printf("Failed to read \"%s\"\n", keyFile);
		return 0;
	}
	
	
	hash_process(&state, buffer, counter);
	memcpy(hash, &state, HASH_SIZE);

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("hash of the given key: \n");
		for(int i=0; i<HASH_SIZE; i++) printf("%02x ", hash[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	return 1;
}



/*
This function does the following
1) hash the key from encK.txt
2) read hdr from HDR.txt
3) create a third file H_HDR.txt that contains: (4 bytes subscribers list || LSB 12 bytes of hash || HDR)
*/
int generate_hash()
{

	FILE *fp;
	int counter;



	FILE *subscribers_file; 

	//1- open and subscriber's list file
	subscribers_file = fopen (subscribers_file_name, "r"); 

	if(subscribers_file == NULL)
	{
		printf("subscribers list file: (%s) does not exist. \n", subscribers_file_name);
		return 0;
	}

	char list_content[4]; //This is hardcoded and should somewhow be changed.

	int actual_length = fread(list_content,1,4,subscribers_file);
	fclose(subscribers_file);


	//2- hash encryption key file
	if(!hash_key()) return 0;

	//3- read HDR to new file
	fp = fopen(hdrFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END)) 
	{
		printf("#  fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}


	int hdr_size = ftell(fp);

	printf("\n\nHDR file size: (%d) \n", hdr_size);

	fclose(fp);

	//open file for reading
	fp = fopen(hdrFile, "r");
	// Read HDR into buffer
	counter = fread(buffer, 1, hdr_size, fp);

	fclose(fp);

	if(counter != hdr_size)
	{
		printf("Failed to read \"%s\"\n", hdrFile);
		return 0;
	}

	
	//4- create new file (HHDR.txt)
	fp = fopen(h_hdrFile, "w");


	//5- write 4 bytes subscribers list to new file
	//first, fill remaining bytes with values of 99
	for(int i=actual_length; i<4; i++)list_content[i]=99;

	counter = fwrite(list_content, 1, 4, fp);
	printf("counter for  fwrite(hash, 1, 4, fp) = (%d) \n", counter);
	if(counter != 4)
	{
		printf("\nFAILURE: writing subscribers list to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}

	//6- write LSB 12 byets of hash to new file.(bytes 0...11)
	counter = fwrite(hash, 1, 12, fp);
	printf("counter for  fwrite(hash, 1, 12, fp) = (%d) \n", counter);
	if(counter != 12)
	{
		printf("\nFAILURE: writing hash to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}

	

	//7- write HDR to new file
	counter = fwrite(buffer, 1 , hdr_size, fp);
	printf("counter for fwrite(buffer, 1 , hdr_size, fp) = (%d) \n", counter);
	if(counter != hdr_size)
	{
		printf("\nFAILURE: writing HDR to H_HDR file: %s.\n", h_hdrFile);
		fclose(fp);
		return 0;
	}
	

	fclose(fp);

	return 1;
}



/*
This function reads h_hdrfile and produces four files auth_msg.txt, subscriber.txt, hdr.txt and hash_part.txt*/
int partition_file()
{
	FILE *fp;
	int counter;


	//1- read H_HDR to new file
	fp = fopen(h_hdrFile, "r");

	// find the size of the file
	if(fseek(fp, 0, SEEK_END)) 
	{
		printf("#  fseek(fp, 0, SEEK_END) returned false\n");
		fclose(fp);
		return 0;
	}

	int h_hdr_size = ftell(fp);
	if(!release) printf("\n\nH_HDR file size: (%d) \n", h_hdr_size);
	fclose(fp);

	//open file for reading
	fp = fopen(h_hdrFile, "r");
	// Read HDR into buffer
	counter = fread(buffer, 1, h_hdr_size, fp);
	fclose(fp);
	if(counter != h_hdr_size)
	{
		printf("Failed to read \"%s\"\n", h_hdrFile);
		return 0;
	}

	//char new_hdrFile[11] = "n_HDR.txt";
	//char part_hash_file[10] = "hash.txt";

	//3- create a new file and write the first 64 bytyes to it
	fp = fopen(output_authentication_msg, "w");
	counter = fwrite(buffer, 1 , total_num_of_users, fp);
	if(!release) printf("counter for fwrite(buffer, 1 , total_num_of_users, fp) = (%d) \n", counter);
	if(counter != total_num_of_users)
	{
		printf("\nFAILURE: writing 1st %d bytes to auth_msg file: %s.\n", total_num_of_users, output_authentication_msg);
		fclose(fp);
		return 0;
	}
	fclose(fp);


	

	//display binary encoded subscribers list
	if(!release)
	{
		printf("\n\n");
		for(int i=0; i<8; i++) printf("binary encoded value [%d]: %02x \n", i, buffer[total_num_of_users+i]);
	}
	
	int binary_value_one = 0;
	int binary_value_two = 0;
	int temp = 0;
	for(int i=0; i<8; i++)
	{
		temp = buffer[total_num_of_users+i];
		if(i<4)
		{
			temp  = temp << (i*8);
			binary_value_one = binary_value_one | temp;
		}
		else
		{
			temp  = temp << ((i-4)*8);
			binary_value_two = binary_value_two | temp;
		}
	}
	if(!release) printf("\nbinary_value_one: %d \n", binary_value_one);
	if(!release) printf("\nbinary_value_two: %d \n", binary_value_two);

	unsigned char list[total_num_of_users];
	int actual_num_of_subscribers = 0;
	for(int i=0; i<total_num_of_users; i++)
	{
		if(i<32)
		{
			temp = 1 << i;
			if(binary_value_one & temp)
			{
				if(!release) printf("\n user index (%d) is a subscriber \n",i);
				list[actual_num_of_subscribers++]=i;
			}
		}
		else
		{
			temp = 1 << (i-32);
			if(binary_value_two & temp)
			{
				if(!release) printf("\n user index (%d) is a subscriber \n",i);
				list[actual_num_of_subscribers++]=i;
			}
		}
	}

	//fill the rest with the value of 99
	for(int i=actual_num_of_subscribers; i<total_num_of_users; i++) list[i]= 99;

	
	if(!release)
	{
		printf("\n\n");
		for(int i=0; i<total_num_of_users; i++) printf("list[%d]: %02x ", i, list[i]);
	}

	//4- create a new file and write 4 bytes to it
	fp = fopen(output_subscribers_list, "w");
	counter = fwrite(list, 1 , total_num_of_users, fp);
	if(!release) printf("counter for fwrite(list, 1 , 32, fp) = (%d) \n", counter);
	if(counter != total_num_of_users)
	{
		printf("\nFAILURE: writing 32 bytes to subscribers file: %s.\n", output_subscribers_list);
		fclose(fp);
		return 0;
	}
	fclose(fp);
	/*
	fp = fopen(output_subscribers_list, "w");
	counter = fwrite(&buffer[16], 1 , 4, fp);
	if(!release) printf("counter for fwrite(&buffer[16], 1 , 4, fp) = (%d) \n", counter);
	if(counter != 4)
	{
		printf("\nFAILURE: writing 4 bytes to subscribers file: %s.\n", output_subscribers_list);
		fclose(fp);
		return 0;
	}
	fclose(fp);
	*/
	
	//4- create a new file and write 12 bytes to it.
	fp = fopen(part_hash_file, "w");
	

	//write 1st 12 bytes from buffer to new file
	counter = fwrite(&buffer[8+total_num_of_users], 1 , 12, fp);
	if(!release) printf("counter for fwrite(&buffer[8+total_num_of_users], 1 , 12, fp) = (%d) \n", counter);
	if(counter != 12)
	{
		printf("\nFAILURE: writing 12 bytes to Hash file: %s.\n", part_hash_file);
		fclose(fp);
		return 0;
	}
	fclose(fp);

	//5- create a new file and write remaining bytes to it (write HDR to new file).
	fp = fopen(new_hdrFile, "w");

	//write 1st 16 bytes from buffer to new file
	counter = fwrite(&buffer[8+total_num_of_users+12], 1 , (h_hdr_size-(8+total_num_of_users+12)), fp);
	if(!release) printf("counter for fwrite(&buffer[8+total_num_of_users+12], 1 , (h_hdr_size-(8+total_num_of_users+12)), fp) = (%d) \n", counter);
	if(counter != (h_hdr_size-(8+total_num_of_users+12)))
	{
		printf("\nFAILURE: writing HDR to new file: %s.\n", new_hdrFile);
		fclose(fp);
		return 0;
	}
	fclose(fp);


	return 1;

	
}




/*
This function reads and hashes encK.txt
and compare the 1st 12 bytes of the hash value with the bytes in hash.txt
return 1 --> successful (same values)
return 0 --> not the same.
*/
int check()
{

	//1- hash key in encK.txt
	if(!hash_key())
	{
		printf("\nFAILURE: problem in hash_key().\n");
		return 0;
	}

	//2- read part_hash_file
	FILE *fp = fopen(part_hash_file, "r");
	int counter = fread(buffer, 1, 12, fp);
	fclose(fp);
	if(counter != 12)
	{
		printf("Failed to read \"%s\"\n", part_hash_file);
		return 0;
	}

	if(!release)
	{
		printf("-------------------------------------------------------------------------\n");
		printf("Read hash value: \n");
		for(int i=0; i<12; i++) printf("%02x ", buffer[i]);
		printf("\n");
		printf("-------------------------------------------------------------------------\n");
	}

	//3 - compare hash read from file and computed hash value 
	int not_the_same = 0;
	for(int i=0; i<12; i++)
	{
		if(buffer[i] != hash[i]) not_the_same = 1;
	}

	if(not_the_same)
	{
		printf("\nINFO: the read value from hash file does not match computed hash value of enc key.\n");
		return 0;
	}

	return 1;
}

// main
int main(int argc, char **argv)
{
	
	

#if get_from_argv

	int option = (argc > 1) ? atoi(argv[1]) : 0;
	release = (argc > 2) ? atoi(argv[2]) : 0;

	if(!release) printf("argv[1]: %s \n", argv[1]);
	if(!release) printf("argv[2]: %s \n", argv[2]);

	
#endif	

#if get_from_terminal
	int option;
	release = 0;
	do
	{
	
		printf("\n\n************************************************************************ \n"); 
		printf("Enter (0) to generate hash for a given encK.txt and add it with HDR.txt to a new file H_HDR.txt.\n");
		printf("Enter (1) to partition H_HDR.txt into hash.txt, subscribers list, and n_HDR.txt.\n");
		printf("Enter (2) to hash encK.txt and compare the 1st 12 bytes with the values in hash.txt.\n");
		printf("************************************************************************ \n");
		
		option = getchar() - 48;
		printf("option: %d \n", option);

		if((option < 0)||(option > 2))
		{
			printf("Invalid input \n");
		}
	}while((option < 0)||(option > 2));
#endif	
		 
	


	if(!release) printf("ha - option: %d \n", option);
	if(!release) printf("ha - release: %d \n", release);

	if(!release)
	{
		printf("\n\n************************************************************************ \n"); 
		printf("This is add_checksum - ha.\n");
		printf("************************************************************************ \n");
	}

	if((option < mode_generate) || (option > mode_authenticate_hdr))
	{
		printf("\nInvalid option - choose either mode_generate or mode_check.\n");
		return 0;
	}

	current_mode = option;

	if(current_mode == mode_generate)
	{
		if(!release) printf("\nCurrent mode ha: mode_generate.\n");
		if(generate_hash())
		{
			printf("\nSUCCESS: generate_hash() is successful.\n");
			return 0;
		}
		else
		{
			printf("\nFAILURE: problem in generate_hash().\n");
			return 1;
		}
	}
	else if(current_mode == mode_partition)
	{
		if(!release) printf("\nCurrent mode ha: mode_partition.\n");
		if(partition_file())
		{
			if(!release) printf("\nSUCCESS: partition_file() is successful.\n");
			return 0;
		}
		else
		{
			printf("\nFAILURE: problem in partition_file().\n");
			return 1;
		}
	}
	else if(current_mode == mode_check)
	{
		if(!release) printf("\nCurrent mode ha: mode_check.\n");
		if(check())
		{
			if(!release) printf("\nSUCCESS: check() is successful.\n");
			return 0;
		}
		else
		{
			if(!release) printf("\nFAILURE: problem in check().\n");
			return 1;
		}
	}
	else if(current_mode == mode_hash_key)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_hash_key, argv[3]:%s and and argv[4]: %s.\n", argv[3], argv[4]); 

			if(hash_private_key(argv[3],argv[4]))
			{
				if(!release) printf("\nSUCCESS: hash_private_key() is successful.\n");
				return 0;
			}
			else
			{
				printf("\nFAILURE: problem in hash_private_key().\n");
				return 1;	
			}
		}
		else
		{
			printf("\nFAILURE: provide name of private key file and hash file.\n");
			return 1;
		}
	}
	else if(current_mode == mode_check_hash_key)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_check_hash_key, argv[3]:%s and and argv[4]: %s.\n", argv[3], argv[4]); 

			if(check_hash_private_key(argv[3],argv[4]))
			{
				if(!release) printf("\nSUCCESS: check_hash_private_key() is successful.\n");
				return 0;
			}
			else
			{
				printf("\nFAILURE: problem in check_hash_private_key().\n");
				return 1;	
			}
		}
		else
		{
			printf("\nFAILURE: provide name of private key file and hash file.\n");
			return 1;
		}
	}
	else if(current_mode == mode_index_and_hash)
	{
		if(argc > 4)
		{
			if(!release) printf("\nMode == mode_index_and_hash, argv[3]:%s and argv[4]: %s.\n", argv[3], argv[4]); 

			return (get_index_and_hash(argv[3],argv[4]));

		}
		else
		{
			printf("\nFAILURE: provide subscription request and hash file name.\n");
			return 99; //failure
		}

	}
	else if(current_mode == mode_authenticate_hdr)
	{
		if(argc < 4)
		{
			printf("\nFAILURE: provide user's index and private key file.\n");
			return 1;
		}


		if(!release) printf("\nMode == mode_authenticate_hdr, user's index: %s and private key file: %s \n", argv[3], argv[4]);

		return (!authenticate_hdr(argv[3], argv[4]));

		
	}

	
	printf("\n");
	printf("\n");
	
	
	
    

    	return 0;
}
