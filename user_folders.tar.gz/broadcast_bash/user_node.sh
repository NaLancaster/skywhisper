#!/bin/bash
HHDR_file="/home/user/Desktop/broadcast_bytecoin/bcndev/H_HDR.txt"
broadcast_msg_file="/home/user/Desktop/broadcast_bytecoin/bcndev/received_msg.txt"
PK_file="keys/PK.txt"
local_HHDR_file="H_HDR.txt"
local_msg_file="received_msg.txt"
hash_file="hash_private.txt"
private_key_file=""
subscribers_file="keys/subscribers.txt"
HDR_file="keys/HDR.txt"
encK_file="keys/encK.txt"
user_index=""

subscribe=1
display=2
broadcast=3
disp=9


RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color
#printf "I ${RED}love${NC} Stack Overflow\n"
#echo -e "I ${RED}love${NC} Stack Overflow"


release=1




#This function continuously check for new HHDR file that was received from server/central node.
#if so, it starts the 'decoding' process to get HDR, and consequently the new broadcast encryption key.
check_new_hdr () {

	#printf "check_new_hdr() is started.\n"


	#check if H_HDR.txt exists in bcndev directory
	if [ -f "$HHDR_file" ]
	then
		#echo "$HHDR_file is found"
		echo -e "${RED}INFO:${NC} new HDR command is received."

		
		#move this file to current directory
		mv $HHDR_file .


		#partition H_HDR.txt into n_HDR.txt hash.txt and subscribers.txt
		/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 1 $release

		#rename n_HDR.txt to HDR.txt
		mv n_HDR.txt $HDR_file


		#echo INSPECT FILES\: HDR + AUTH MSG + SUBSCRIBERS + HASH

		
		#before proceeding, authenticate that this HDR is received from central/master node
		/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 6 $release $user_index $private_key_file

		if [ "$?" == "0" ]
		then
			printf "${RED}INFO:${NC} new HDR is successfully authenticated. \n"

			#extract broadcast encryption key (the number of users is hardcoded - here n = 64)
			#echo subscribers \file\: $subscribers_file and private key \file\: $private_key_file
			/home/user/Desktop/broadcast_bytecoin/PBC_BKEM-master/./extractK 64 $user_index $subscribers_file $private_key_file 1


			#check correctness of generated encK.txt
			/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 2 $release

			if [ "$?" == "0" ]
			then
				printf "\n\n${GREEN}INFO: You have successfully subscribed (new key in encK.txt).\n${NC}"
			else
				printf "\n\n${RED}INFO: Your subscription has been revoked.\n${NC}"
				rm $encK_file
				rm $HDR_file
			fi

			#remove meta data
			rm $local_HHDR_file && rm hash.txt
		else
			printf "\n${RED}INFO:${NC} new HDR failed authentication - subscription status unchanged.\n"
		fi

		#display menu
		display_list
		
	fi

	#printf "check_new_hdr() is finished.\n"

}



check_new_broadcast_msg () {

	#printf "check_new_broadcast_msg() is started.\n"


	#check if broadcast message file is detected in bcndev directory
	if [ -f "$broadcast_msg_file" ]
	then
		#echo "$broadcast_msg_file is found"
		echo -e "${RED}INFO:${NC} a new broadcast message is received."

		#move this file to current directory
		mv $broadcast_msg_file .
		
		#check if you have broadcast encryption key: encK_file
		if [ -f "$encK_file" ]
		then
			#decrypt and extract message.
			/home/user/Desktop/broadcast_bytecoin/encrypt_decrypt/./enc_engine 1 1

			if [ "$?" == "0" ]
			then
				echo -e "${RED}INFO:${NC} message is successfully extracted and decrypted."

				message=$(cat dmsg.txt)
				printf "\n*************************************************************************\n"
				echo -e "${RED}INFO:${NC} received message is: {${PURPLE}$message${NC}}"
				printf "***************************************************************************\n"

				#remove dmsg.txt file
				rm dmsg.txt 
			else
				echo FAILURE IN DECRYPTING MESSAGE 
			fi

			
		else
			echo -e "${RED}INFO:${NC} DON'T decrypt message as you dont have the broadcast encryption key."
		fi
		
		rm $local_msg_file

		#display menu
		display_list

	fi

	#printf "check_new_broadcast_msg() is finished.\n"
}


#This function invokes /home/user/Desktop/wallet_bash/create_and_send.sh
send_transaction () {
	#printf "This is send_transaction function\n"

	#before invoking create+send transaction, copy packet.txt to same directory as wallet
	cp packet.txt ~/Desktop/broadcast_bytecoin/bcndev/ 

	#invoke /home/user/Desktop/wallet_bash/create_and_send.sh
	#/home/user/Desktop/wallet_bash/create_transaction2.sh
	/home/user/Desktop/wallet_bash/create_and_send.sh
}


#This function constructs and sends a subscription request to server.
#before doing so, it checks if this user has any PK and private key files which should be received offline
#1- check if PK.txt and di-n.txt exist
#2- if both exist, then construct a new packet (packet.txt) containing CMD || data
#	where CMD == 2
#	      data == index || LSB 2 bytes of hash(di-n.txt) ==> total = 4 bytes
#3- invoke create_and_send bash
subscribe_to_service () {
	#printf "This is subscribe_to_service () function \n"

	pk_available=0
	private_available=0
	more_than_one=0

	#1- check if public key file (PK.txt) exists
	if [ -f "$PK_file" ]
	then
		#echo "$PK_file is found"

		pk_available=1
	fi


	num_of_private_files=$(ls keys\/di-* | wc -l)

	#echo num_of_private_files\: $num_of_private_files

	if [ "$num_of_private_files" -gt 1 ]
	then
		echo FAILURE\: You can not subscribe as you have \more than one private key \file,
		echo Make sure to have only one \file.
		
		more_than_one=1
	fi


	if [ "$num_of_private_files" -eq 1 ]
	then
		
		private_key_file=$(ls keys\/di-*)

		#echo One private key \file is found\:  $private_key_file

		user_index=$(echo $private_key_file | cut -c9-10)

		echo -e "${RED}INFO:${NC} This user index is:  $user_index"


		private_available=1
	fi

	#2 hash private key
	/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 3 $release $private_key_file $hash_file

	hash=0
	if [ "$?" == "0" ]
	then
		#echo Key is successfully hashed.
		hash_value=$(cat $hash_file)

		#echo \hash value\: $hash_value
		hash=1
	else
		echo -e "${RED}INFO:${NC} FAILURE in hashing file." 
	fi
	

	#3- hash is okay and both files exist, construct a new packet (packet.txt) containing CMD || data
	#	where CMD == 2
	#	      data == index || LSB 2 bytes of hash(di-n.txt) ==> total = 4 bytes
	if [ "$hash" -eq 1 ] && [ "$pk_available" -eq 1 ] && [ "$private_available" -eq 1 ]
	then

		#echo Both private and public keys exist and key successfully hashed - \then proceed to create packet.txt
		
		#remove old key + HDR + subscribers files if any exists
		if [ -f "$subscribers_file" ]
		then
			#echo $subscribers_file exists - remove it

			rm $subscribers_file
		fi

		if [ -f "$HDR_file" ]
		then
			#echo $HDR_file exists - remove it

			rm $HDR_file
		fi

		if [ -f "$encK_file" ]
		then
			#echo $encK_file exists - remove it

			rm $encK_file
		fi
		
		
		#remove packet.txt if it exists
		if [ -f packet.txt ]
		then
			#echo packet.txt exists - remove it

			rm packet.txt
		fi
		
		#create new packet.txt file
		touch packet.txt

		

		cmd=2
		
		echo -n -e $cmd > packet.txt && echo -n -e $user_index >> packet.txt && echo -n -e $hash_value >> packet.txt


		#4- send the created command packet
		send_transaction

		echo -e "${RED}INFO:${NC} Subscription request is sent successfully."


		#remove META data files hash_file
		rm $hash_file && rm packet.txt
	else
		echo FAILURE\: Either one or both public and private keys are not available.
	fi

}

#This function displays this subscriber's information:
#1- the existance of a public and a private key files.
#2- the user index.
#3- subscription status.
display_information () {

	#printf "This is display_information () function \n"
	
	echo -e "${BLUE}"	
	echo '*******************************************************************'

	echo User information\: 

	pk_available=0
	private_available=0
	more_than_one=0

	#1- check if public key file (PK.txt) exists
	if [ -f "$PK_file" ]
	then
		echo 1- Public key file\: $PK_file

		pk_available=1
	fi


	num_of_private_files=$(ls keys\/di-* | wc -l)

	echo 2- The number of available private key files\: $num_of_private_files

	if [ "$num_of_private_files" -gt 1 ]
	then
		echo NOTE\: You can not subscribe as you have \more than one private key \file,
		#echo Make sure to have only one \file.
		
		more_than_one=1
	fi


	if [ "$num_of_private_files" -eq 1 ]
	then
		
		private_key_file=$(ls keys\/di-*)

		echo 3- Private key \file is\:  $private_key_file

		user_index=$(echo $private_key_file | cut -c9-10)

		echo 4- User index is\:  $user_index


		private_available=1
	fi

	if [ -f "$encK_file" ]
	then
		echo 5- You seem to have subscribed, as broadcast key \file exists.
	else
		echo 5- You DON\'T seem to have subscribed, as NO broadcast key \file is found.
	fi
	echo '*******************************************************************'
	echo -e "${NC}"
}


#This function constructs and sends a revocation request to server.
#before doing so, it checks if this user has any PK and private key files which should be received offline
#1- check if PK.txt and di-n.txt exist
#2- if both exist, then construct a new packet (packet.txt) containing CMD || data
#	where CMD == 3
#	      data == index || LSB 2 bytes of hash(di-n.txt) ==> total = 4 bytes
#3- invoke create_and_send bash
revoke_subscription () {
	printf "This is revoke_subscription () function \n"



	pk_available=0
	private_available=0
	more_than_one=0

	#1- check if public key file (PK.txt) exists
	if [ -f "$PK_file" ]
	then
		echo "$PK_file is found"

		pk_available=1
	fi


	num_of_private_files=$(ls keys\/di-* | wc -l)

	echo num_of_private_files\: $num_of_private_files

	if [ "$num_of_private_files" -gt 1 ]
	then
		echo FAILURE\: You can not un-subscribe as you have \more than one private key \file,
		echo Make sure to have only one \file.
		
		more_than_one=1
	fi


	if [ "$num_of_private_files" -eq 1 ]
	then
		
		private_key_file=$(ls keys\/di-*)

		echo One private key \file is found\:  $private_key_file

		user_index=$(echo $private_key_file | cut -c9-10)

		echo Index is\:  $user_index


		private_available=1
	fi

	#2 hash private key
	/home/user/Desktop/broadcast_bytecoin/add_checksum/./ha 3 $release $private_key_file $hash_file

	hash=0
	if [ "$?" == "0" ]
	then
		echo Key is successfully hashed.
		hash_value=$(cat $hash_file)

		echo \hash value\: $hash_value
		hash=1
	else
		echo FAILURE \in hashing file. 
	fi
	

	#3- if hash is okay and both files exist, construct a new packet (packet.txt) containing CMD || data
	#	where CMD == 2
	#	      data == index || LSB 2 bytes of hash(di-n.txt) ==> total = 4 bytes
	if [ "$hash" -eq 1 ] && [ "$pk_available" -eq 1 ] && [ "$private_available" -eq 1 ]
	then

		echo Both private and public keys exist and key successfully hashed - \then proceed to create packet.txt
		
		
		
		#remove packet.txt if it exists
		if [ -f packet.txt ]
		then
			echo packet.txt exists - remove it

			rm packet.txt
		fi
		
		#create new packet.txt file
		touch packet.txt

		

		cmd=3
		
		echo -n -e $cmd > packet.txt && echo -n -e $user_index >> packet.txt && echo -n -e $hash_value >> packet.txt


		#4- send the created command packet
		send_transaction

		printf "\n**** Revocation request is sent. ****\n"


		printf "\n**** Remove all previous .txt files ****\n"
		#5-clean this directory of meta data and old files
		rm $hash_file && rm packet.txt
		rm $subscribers_file && rm $HDR_file && rm $encK_file

	else
		echo FAILURE\: Either one or both public and private keys are not available, or key is not hashed.
	fi

}


broadcast_msg () {
	#printf "This is broadcast_msg () function \n"

	#check if encK.txt file exists (i.e. this user is a subscriber)
	if [ -f "$encK_file" ]
	then
		printf "Enter your broadcast message here (Less than 200 bytes): "
		read message

		#msg_length=$(expr length $message)
		msg_length=$(echo $message | awk '{print length}')

		echo -e "\n${RED}INFO:${NC} message length: $msg_length Bytes."

		if [ $msg_length -le 200 ]
		then
			echo -e "${RED}INFO:${NC} entered message: {$message}"


			#remove msg.txt if it already exists
			if [ -f msg.txt ]
			then
				rm msg.txt
			fi

			#create msg.txt
			touch msg.txt

			echo -n -e $message > msg.txt

			#execute enc_engine and pass 0 0 (encryption + release)
			/home/user/Desktop/broadcast_bytecoin/encrypt_decrypt/./enc_engine 0 1


			#remove packet.txt if it exists
			if [ -f packet.txt ]
			then
				#echo packet.txt exists - remove it

				rm packet.txt
			fi
			
			#create new packet.txt file
			touch packet.txt

			
			cmd=4
			echo -n -e $cmd > packet.txt && cat emsg.txt >> packet.txt


			#3- send the created command packet
			send_transaction

			echo -e "${RED}INFO:${NC} Broadcast message is sent successfully."


			#remove msg.txt, emsg.txt and packet.txt
			rm msg.txt && rm packet.txt && rm emsg.txt
		else

			echo -e "${RED}INFO: Although it is possible to broadcast long messages, "
			echo -e "     we limit the length of messages in this proof-of-concept to 200 Bytes.${NC}"
		fi

		
	else
		echo '*****************************************************************'
		echo -e "*** ${RED}INFO: encK.txt does not exist. Check your subscription.${NC} ***"
		echo '*****************************************************************'
	fi
}



display_list () {

	echo ' '
	echo '************************************************************************'
	printf "Press 1: to subscribe. \n"
	printf "Press 2: to display information. \n"
	printf "Press 3: to broadcast a message. \n"
	printf "Press 9: to display this list. \n"
	echo '************************************************************************'
	echo ' '


}


printf "***************************************************************************************\n"
printf "This is user-node. It continuously observes incoming HDR and broadcast msg commands.\n"
printf "***************************************************************************************\n"


display_list

while true
do

	
	read -t 1 option


	if [ -z "$option" ]
	then
		no_input=1
	else
		no_input=0
	fi

	if [ $no_input -eq 0 ]
	then
		#echo selected option\: $option

		if [ "$option" -lt "$subscribe" ] || [ "$option" -gt "$disp" ]
		then
			echo Invalid input.
		fi

		if [ "$option" -eq "$subscribe" ]
		then
			subscribe_to_service
		fi

		if [ "$option" -eq "$display" ]
		then
			display_information
		fi

		if [ "$option" -eq "$broadcast" ]
		then
			broadcast_msg
		fi

		#if [ "$option" -eq "$disp" ]
		#then
			display_list
		#fi

		
	fi

	
	
	#temporary_check_new_hdr
	check_new_hdr
	check_new_broadcast_msg


done
