#!/bin/bash

#printf $"create and send transaction.\n"
#printf $"1)Create transaction.\n"

whole_string=$(curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "create_transaction",
  "params": {
    "transaction": {
      "anonymity": 8,
      "payment_id": "",
      "transfers": [
        {
          "address": "21S7AgTDkwd7xSJFCoMua3eDjWfTcUYGrLZU1toage6wYde89BRDWCwhriw2cDepAYV9apPbDovCDVFCgtRoRW1TFjxAFfv",
          "amount": 1000000
		    
        }
      ]
    },
    "spend_addresses": [
      "21S7AgTDkwd7xSJFCoMua3eDjWfTcUYGrLZU1toage6wYde89BRDWCwhriw2cDepAYV9apPbDovCDVFCgtRoRW1TFjxAFfv"
    ],
    "change_address": "21S7AgTDkwd7xSJFCoMua3eDjWfTcUYGrLZU1toage6wYde89BRDWCwhriw2cDepAYV9apPbDovCDVFCgtRoRW1TFjxAFfv",
    "optimization": "minimal"
  }
}')

#echo $whole_string

#echo "----------------"

tx_binary=$(echo $whole_string | jq '.result.binary_transaction')

#echo ' '
#echo $tx_binary
#echo ' '


#printf $"2)Transfer payment.\n"



send_string=$(curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
	"jsonrpc": "2.0", 
	"id": "0", 
	"method": "send_transaction", 
	"params": { "binary_transaction":'$tx_binary'}}')
#echo $send_string







