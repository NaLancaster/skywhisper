#!/bin/bash

printf $"Transfer payment.\n"

curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "create_transaction",
  "params": {
    "transaction": {
      "anonymity": 5,
      "payment_id": "",
      "transfers": [
        {
          "address": "29veqf7y31dFNR8174ZeJg3FWEFXesy6zJuZp6aa9tbyL27Mn8mWHZLiinGaX9pbtuXtWvrm8Dyu2RBeNSRErJQDFx7QhZT",
          "amount": 100000000
        }
      ]
    },
    "spend_addresses": [
      "29veqf7y31dFNR8174ZeJg3FWEFXesy6zJuZp6aa9tbyL27Mn8mWHZLiinGaX9pbtuXtWvrm8Dyu2RBeNSRErJQDFx7QhZT"
    ],
    "change_address": "29veqf7y31dFNR8174ZeJg3FWEFXesy6zJuZp6aa9tbyL27Mn8mWHZLiinGaX9pbtuXtWvrm8Dyu2RBeNSRErJQDFx7QhZT",
    "optimization": "minimal"
  }
}'


printf $"\n"


