#! /bin/bash

printf $"This is: transaction_binary_extractor\n"


json_string=$(curl -s -u user:password -X POST http://127.0.0.1:8070/json_rpc -H 'Content-Type: application/json-rpc' -d '{
  "jsonrpc": "2.0",
  "id": "0",
  "method": "create_transaction",
  "params": {
    "transaction": {
      "anonymity": 29,
      "payment_id": "",
      "transfers": [
        {
          "address": "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6",
          "amount": 100000000
		    
        }
      ]
    },
    "spend_addresses": [
      "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6"
    ],
    "change_address": "26c6YmZmLJZYxnVAt56kRraBhxiEUt8yoJR3VV4UV5VcRM9Pzs5qV7KStQHaa7xkAHej3WTTxtAc1KHbCSPoZ2ms3bdUsY6",
    "optimization": "minimal"
  }
}')

printf $"The output is the following: \n"
echo $json_string

tx_binary=$(echo $json_string | jq '.result.binary_transaction')



printf $"\n\nExtracted tx binary: \n\n"
echo $tx_binary


